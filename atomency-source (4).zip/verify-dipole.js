/**
 * Verify dipole moment calculations against known experimental values.
 * Uses the same formulas from vsepr-geometry.js calculateNetDipole.
 */

// Bond dipole formula: mu = 1.121 * deltaEN^0.924
function bondDipole(deltaEN) {
    return deltaEN > 0.01 ? 1.121 * Math.pow(deltaEN, 0.924) : 0;
}

// Test molecules with known experimental dipole moments
const tests = [
    {
        name: 'HF (diatomic)',
        expected: 1.91,
        calc: () => bondDipole(1.78) // F=3.98, H=2.20, diff=1.78
    },
    {
        name: 'HCl (diatomic)',
        expected: 1.08,
        calc: () => bondDipole(0.96) // Cl=3.16, H=2.20, diff=0.96
    },
    {
        name: 'CO2 (linear, symmetric)',
        expected: 0,
        calc: () => 0 // Symmetric identical bonds cancel
    },
    {
        name: 'H2O (bent 2-2, 104.5 deg, 2 LP)',
        expected: 1.85,
        calc: () => {
            const mu_OH = bondDipole(1.24); // O=3.44, H=2.20
            const angle = 104.5 * Math.PI / 180;
            const rawDipole = 2 * mu_OH * Math.cos(angle / 2);
            // LP correction: central O (3.44) > terminal H (2.20), sign=+1
            // Bent 2-2: alignment=0.139
            const lpFactor = 1 + 1 * 0.380 * 2 * 0.139;
            return rawDipole * lpFactor;
        }
    },
    {
        name: 'NH3 (pyramidal 3-1, 107 deg, 1 LP)',
        expected: 1.47,
        calc: () => {
            const mu_NH = bondDipole(0.84); // N=3.04, H=2.20
            const angle = 107 * Math.PI / 180;
            const cosAlpha = Math.cos(angle);
            const cosBetaSq = (cosAlpha + 0.5) / 1.5;
            const cosBeta = Math.sqrt(cosBetaSq);
            const rawDipole = 3 * mu_NH * cosBeta;
            // LP correction: central N (3.04) > terminal H (2.20), sign=+1
            // Pyramidal: alignment=1.0
            const lpFactor = 1 + 1 * 0.380 * 1 * 1.0;
            return rawDipole * lpFactor;
        }
    }
];

console.log('=== DIPOLE MOMENT VERIFICATION ===\n');
let allPass = true;

for (const test of tests) {
    const calculated = test.calc();
    const diff = Math.abs(calculated - test.expected);
    const pctErr = test.expected > 0 ? (diff / test.expected * 100).toFixed(1) : (diff === 0 ? 0 : 'N/A');
    const pass = diff < 0.05;

    console.log(`${pass ? 'PASS' : 'FAIL'} | ${test.name}`);
    console.log(`  Calculated: ${calculated.toFixed(3)} D`);
    console.log(`  Expected:   ${test.expected.toFixed(3)} D`);
    console.log(`  Error:      ${diff.toFixed(3)} D (${pctErr}%)\n`);

    if (!pass) allPass = false;
}

console.log(allPass ? '=== ALL TESTS PASSED ===' : '=== SOME TESTS FAILED ===');
process.exit(allPass ? 0 : 1);
