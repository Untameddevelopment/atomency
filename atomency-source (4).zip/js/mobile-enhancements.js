/**
 * ATOMENCY MOBILE ENHANCEMENTS
 * Touch gestures and mobile-specific adaptations
 * Panel toggles are now handled by the top toolbar buttons (index.html)
 */

(function() {
    const isMobile = () => window.innerWidth <= 768;

    // Intercept inspector panel visibility logic
    const originalUpdateInspector = window.updateInspector;
    if (typeof originalUpdateInspector === 'function') {
        window.updateInspector = function(atom, molecule) {
            originalUpdateInspector(atom, molecule);
            // Panel no longer auto-opens on atom selection - user clicks toolbar button
        };
    }

    // Enhanced touch input support for molecular builder canvas
    function setupTouchGestures() {
        const canvas = document.getElementById('canvas');
        if (!canvas) return;

        let touches = [];
        let initialDistance = 0;
        let initialZoom = 1;
        let lastCenter = { x: 0, y: 0 };
        let isPinching = false;

        canvas.addEventListener('touchstart', (e) => {
            touches = Array.from(e.touches).map(t => ({ x: t.clientX, y: t.clientY }));
            if (touches.length === 2) {
                isPinching = true;
                initialDistance = Math.hypot(touches[1].x - touches[0].x, touches[1].y - touches[0].y);
                if (window.viewState) initialZoom = window.viewState.zoom || 1;
                lastCenter = { x: (touches[0].x + touches[1].x) / 2, y: (touches[0].y + touches[1].y) / 2 };
            }
        }, { passive: true });

        canvas.addEventListener('touchmove', (e) => {
            if (touches.length === 2 && isPinching) {
                e.preventDefault();
                const ct = Array.from(e.touches);
                const dist = Math.hypot(ct[1].clientX - ct[0].clientX, ct[1].clientY - ct[0].clientY);
                const newZoom = Math.min(Math.max(initialZoom * (dist / initialDistance), 0.2), 10);
                const rect = canvas.getBoundingClientRect();
                const cx = lastCenter.x - rect.left, cy = lastCenter.y - rect.top;
                if (window.viewState) {
                    const wx = (cx - window.viewState.x) / window.viewState.zoom;
                    const wy = (cy - window.viewState.y) / window.viewState.zoom;
                    window.viewState.zoom = newZoom;
                    window.viewState.x = cx - wx * newZoom;
                    window.viewState.y = cy - wy * newZoom;
                    if (typeof window.updateScene === 'function') window.updateScene();
                }
            } else if (touches.length === 2 && !isPinching) {
                e.preventDefault();
                const ct = Array.from(e.touches);
                const cc = { x: (ct[0].clientX + ct[1].clientX) / 2, y: (ct[0].clientY + ct[1].clientY) / 2 };
                if (window.viewState) {
                    window.viewState.x += cc.x - lastCenter.x;
                    window.viewState.y += cc.y - lastCenter.y;
                    if (typeof window.updateScene === 'function') window.updateScene();
                }
                lastCenter = cc;
            }
        }, { passive: false });

        canvas.addEventListener('touchend', () => { isPinching = false; initialDistance = 0; }, { passive: true });
    }

    function setupTouchScrollPrevention() {
        const canvas = document.getElementById('canvas');
        if (canvas) {
            canvas.addEventListener('touchmove', (e) => {
                if (e.touches.length > 1) e.preventDefault();
            }, { passive: false });
        }
    }

    function fixIOSZoom() {
        document.querySelectorAll('input[type="text"], input[type="number"], input[type="email"], textarea, select')
            .forEach(input => { input.style.fontSize = '16px'; });
    }

    // On mobile, auto-close both panels by default (toolbar buttons always available to reopen)
    function setupMobileDefaults() {
        if (!isMobile()) return;
        const controls = document.getElementById('controls-panel');
        const inspector = document.getElementById('inspector-panel');
        if (controls && !controls.classList.contains('panel-hidden')) {
            if (typeof window.closeControls === 'function') window.closeControls();
        }
        if (inspector && !inspector.classList.contains('panel-hidden')) {
            if (typeof window.closeInspector === 'function') window.closeInspector();
        }
    }

    function initialize() {
        if (!isMobile()) return;
        const run = () => {
            setupMobileDefaults();
            setupTouchScrollPrevention();
            fixIOSZoom();
            setupTouchGestures();
        };
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => setTimeout(run, 100));
        } else {
            setTimeout(run, 100);
        }
    }

    initialize();
})();
