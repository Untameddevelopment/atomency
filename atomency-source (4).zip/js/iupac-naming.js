/**
 * IUPAC Naming System - Algorithmic, Zero-Hardcoding
 * Generates systematic names for ANY molecule based on structure analysis
 * No lookup tables, no predefined lists — everything is algorithmic
 */

class IUPACNaming {
    constructor(engine) {
        this.engine = engine;

        // IUPAC numeric prefixes for substituents/functional groups
        this.numericPrefixes = {
            1: 'mono', 2: 'di', 3: 'tri', 4: 'tetra', 5: 'penta',
            6: 'hexa', 7: 'hepta', 8: 'octa', 9: 'nona', 10: 'deca',
            11: 'undeca', 12: 'dodeca', 13: 'trideca', 14: 'tetradeca',
            15: 'pentadeca', 16: 'hexadeca', 17: 'heptadeca', 18: 'octadeca',
            19: 'nonadeca', 20: 'icosa'
        };

        // Priority of functional groups (higher = more important for naming)
        this.functionalGroupPriority = {
            'carboxylic_acid': 10,
            'aldehyde': 9,
            'ketone': 8,
            'alcohol': 7,
            'amine': 6,
            'ether': 5,
            'alkene': 4,
            'alkyne': 3,
            'halogen': 2,
            'alkane': 1
        };

        // Electronegativity values for element priority
        this.electronegativity = {
            'F': 3.98, 'O': 3.44, 'N': 3.04, 'Cl': 3.16, 'Br': 2.96, 'I': 2.66,
            'S': 2.58, 'C': 2.55, 'P': 2.19, 'H': 2.20, 'B': 2.04, 'Si': 1.90
        };
    }

    /**
     * Main entry point: generate IUPAC name from atoms and bonds
     */
    generateIUPACName(atoms, bonds) {
        if (!atoms || atoms.length === 0) return 'Unknown';

        // Single atom
        if (atoms.length === 1) {
            return this.nameElemental(atoms[0].element);
        }

        // Count element types
        const composition = this.analyzeComposition(atoms);
        const symbolList = Object.keys(composition).sort();

        // Determine compound type
        const compoundType = this.classifyCompound(atoms, bonds);

        // Route to appropriate naming function
        switch (compoundType) {
            case 'elemental':
                return this.nameElemental(atoms[0].element, atoms.length);
            case 'ionic':
                return this.nameIonicCompound(atoms, bonds, composition);
            case 'organic':
                return this.nameOrganicCompound(atoms, bonds, composition);
            case 'inorganic_covalent':
                return this.nameInorganicCovalent(atoms, bonds, composition);
            default:
                return this.generateFormulaBasedName(atoms, composition);
        }
    }

    /**
     * Analyze atom composition
     */
    analyzeComposition(atoms) {
        const composition = {};
        atoms.forEach(atom => {
            const sym = atom.element.symbol;
            composition[sym] = (composition[sym] || 0) + 1;
        });
        return composition;
    }

    /**
     * Classify compound type based on structure
     */
    classifyCompound(atoms, bonds) {
        const hasMetal = atoms.some(a => this.isMetal(a.element));
        const hasCarbon = atoms.some(a => a.element.symbol === 'C');
        const hasH = atoms.some(a => a.element.symbol === 'H');

        // All same element
        if (atoms.every(a => a.element.symbol === atoms[0].element.symbol)) {
            return 'elemental';
        }

        // Ionic: metal + nonmetal with electron transfer
        if (hasMetal && !hasCarbon) {
            const ionicChar = this.detectIonicCharacter(atoms, bonds);
            if (ionicChar > 0.5) return 'ionic';
        }

        // Organic: contains carbon (usually with H)
        if (hasCarbon && hasH) {
            return 'organic';
        }

        // Organic without H: still carbon-based (like CO2)
        if (hasCarbon) {
            return 'organic';
        }

        // Everything else is inorganic covalent
        return 'inorganic_covalent';
    }

    /**
     * Detect ionic character based on electronegativity difference
     */
    detectIonicCharacter(atoms, bonds) {
        if (bonds.length === 0) return 0;

        let maxCharacter = 0;
        bonds.forEach(bond => {
            const a1 = this.engine.atoms.find(a => bond.a1 && (a.id === bond.a1.id || a === bond.a1));
            const a2 = this.engine.atoms.find(a => bond.a2 && (a.id === bond.a2.id || a === bond.a2));

            if (!a1 || !a2) return;

            const en1 = this.getElectronegativity(a1.element);
            const en2 = this.getElectronegativity(a2.element);
            const diff = Math.abs(en1 - en2);

            // Ionic character roughly follows: 0.3 = 50% ionic, 1.7 = 100% ionic
            const ionicChar = Math.min(1, diff / 1.7);
            maxCharacter = Math.max(maxCharacter, ionicChar);
        });

        return maxCharacter;
    }

    /**
     * Is element a metal?
     */
    isMetal(element) {
        const nonMetals = ['H', 'C', 'N', 'O', 'F', 'Ne', 'P', 'S', 'Cl', 'Ar', 'Se', 'Br', 'Kr', 'I', 'Xe', 'B', 'Si', 'As', 'Sb', 'Te', 'At', 'Rn'];
        return !nonMetals.includes(element.symbol);
    }

    /**
     * Get electronegativity value
     */
    getElectronegativity(element) {
        const sym = element.symbol;
        if (this.electronegativity[sym]) return this.electronegativity[sym];

        // Estimate from position in periodic table
        const period = element.period || 1;
        const group = element.group || 1;
        return 1.0 + (group / 18) + (period / 10);
    }

    /**
     * Name elemental substances
     */
    nameElemental(element, count) {
        if (count === 1) return element.name;

        // Diatomic elements with special names
        const diatomicNames = {
            'H': 'dihydrogen', 'O': 'dioxygen', 'N': 'dinitrogen',
            'F': 'difluorine', 'Cl': 'dichlorine', 'Br': 'dibromine', 'I': 'diiodine'
        };

        if (count === 2 && diatomicNames[element.symbol]) {
            return diatomicNames[element.symbol];
        }

        // Ozone (O3)
        if (element.symbol === 'O' && count === 3) {
            return 'ozone';
        }

        // General: prefix + element name
        const prefix = this.numericPrefixes[count] || `${count}-`;
        return `${prefix}${element.name.toLowerCase()}`;
    }

    /**
     * Name ionic compounds algorithmically
     */
    nameIonicCompound(atoms, bonds, composition) {
        const metals = atoms.filter(a => this.isMetal(a.element));
        const nonMetals = atoms.filter(a => !this.isMetal(a.element));

        // Check if this is actually an acid (H+ bonded to nonmetal anion)
        // Acids are treated differently than ionic compounds
        if (composition['H'] > 0 && metals.length === 0) {
            return this.nameAcid(nonMetals, composition, atoms, bonds);
        }

        if (metals.length === 0 || nonMetals.length === 0) {
            return this.generateFormulaBasedName(atoms, composition);
        }

        // Determine cation and anion
        const cationParts = this.buildCationName(metals, atoms, bonds);
        const anionParts = this.buildAnionName(nonMetals, atoms, bonds);

        // Combine: cation name + space + anion name
        return `${cationParts.name} ${anionParts.name}`;
    }

    /**
     * Name acids (H bonded to nonmetal anion)
     */
    nameAcid(nonMetals, composition, allAtoms, bonds) {
        if (!nonMetals || nonMetals.length === 0) {
            return this.generateFormulaBasedName(allAtoms, composition);
        }

        // Find the central atom (not H, not O usually)
        const centralAtom = nonMetals.find(a => a.element.symbol !== 'H' && a.element.symbol !== 'O');
        if (!centralAtom) {
            // Binary acid: H + one nonmetal
            const nonH = nonMetals.find(a => a.element.symbol !== 'H');
            if (nonH) {
                return `hydro${nonH.element.name.toLowerCase().replace(/ine$/, '')}ic acid`;
            }
            return 'hydroacid';
        }

        // Oxyacid: H + O + central atom
        const oxygenCount = nonMetals.filter(a => a.element.symbol === 'O').length;
        const hydrogenCount = nonMetals.filter(a => a.element.symbol === 'H').length;

        const baseName = this.getAcidBaseName(centralAtom.element, oxygenCount);

        return `${baseName} acid`;
    }

    /**
     * Get the base name for an oxyacid
     */
    getAcidBaseName(centralElement, oxygenCount) {
        const sym = centralElement.symbol;
        const baseName = centralElement.name.toLowerCase().replace(/ine$/, '');

        // Map oxygen count to suffix for acids
        // Rule: -ic acid (most common), -ous acid (fewer oxygens)
        // per-...-ic, ...-ic, ...-ous, hypo-...-ous

        const typicalOxState = {
            'S': 6, 'N': 5, 'P': 5, 'C': 4, 'Cl': 7, 'B': 3
        };

        const typical = typicalOxState[sym] || 4;
        const normalOxygen = Math.ceil(typical / 2);

        if (oxygenCount > normalOxygen + 1) {
            return `per${baseName}ic`;
        } else if (oxygenCount >= normalOxygen) {
            return `${baseName}ic`;
        } else if (oxygenCount === normalOxygen - 1) {
            return `${baseName}ous`;
        } else {
            return `hypo${baseName}ous`;
        }
    }

    /**
     * Build cation name (metal + oxidation state)
     */
    buildCationName(metals, allAtoms, bonds) {
        if (metals.length === 0) return { name: '', formula: '' };

        const metal = metals[0];
        const oxidationState = this.calculateOxidationState(metal, allAtoms, bonds);

        // Prefix for multiple metal atoms
        const metalCount = metals.filter(m => m.element.symbol === metal.element.symbol).length;
        const countPrefix = metalCount > 1 ? this.numericPrefixes[metalCount] : '';

        // Roman numeral for oxidation state (only for transition metals or metals with variable oxidation states)
        const needsRoman = this.shouldUseRomanNumeral(metal.element, oxidationState);
        const romanNum = (needsRoman && oxidationState > 0) ? this.toRomanNumeral(oxidationState) : '';

        const baseName = metalCount > 1 ? `${countPrefix}${metal.element.name}` : metal.element.name;

        return {
            name: `${baseName}${romanNum ? ` (${romanNum})` : ''}`,
            formula: metal.element.symbol + (metalCount > 1 ? metalCount : '')
        };
    }

    /**
     * Determine if a metal cation should use Roman numerals
     * (for transition metals and metals with variable oxidation states)
     */
    shouldUseRomanNumeral(element, oxidationState) {
        const sym = element.symbol;

        // Transition metals
        const transitionMetals = ['Fe', 'Cu', 'Zn', 'Ag', 'Au', 'Pt', 'Ni', 'Co', 'Mn', 'Cr', 'Ti', 'V', 'Pb', 'Sn', 'As', 'Sb'];
        if (transitionMetals.includes(sym)) return true;

        // Alkali metals (Group 1) - usually always +1, no roman numeral needed
        if (element.group === 1) return false;

        // Alkaline earth metals (Group 2) - usually always +2, no roman numeral needed
        if (element.group === 2) return false;

        // Post-transition metals with variable oxidation states
        const variableMetals = ['Pb', 'Sn', 'Bi', 'Tl'];
        if (variableMetals.includes(sym)) return true;

        return false;
    }

    /**
     * Build anion name from non-metal atoms
     */
    buildAnionName(nonMetals, allAtoms, bonds) {
        if (nonMetals.length === 0) return { name: '', formula: '' };

        // Analyze functional groups in anion
        const functionalGroups = this.identifyFunctionalGroups(nonMetals, allAtoms, bonds);

        // Detect polyatomic ions
        if (nonMetals.length === 1) {
            // Simple anion: suffix -ide
            const sym = nonMetals[0].element.symbol;
            return {
                name: this.getSimpleAnionName(nonMetals[0].element),
                formula: sym
            };
        }

        // Multi-atom anion
        const mainElement = nonMetals.reduce((prev, curr) => {
            const prevEN = this.getElectronegativity(prev.element);
            const currEN = this.getElectronegativity(curr.element);
            return currEN > prevEN ? curr : prev;
        });

        return {
            name: this.buildPolyatomicAnionName(mainElement, nonMetals, functionalGroups),
            formula: this.buildFormulaString(nonMetals)
        };
    }

    /**
     * Get simple anion name (for single non-metal atoms)
     */
    getSimpleAnionName(element) {
        const sym = element.symbol;
        const name = element.name.toLowerCase();

        // Common anions
        const knownAnions = {
            'F': 'fluoride', 'Cl': 'chloride', 'Br': 'bromide', 'I': 'iodide',
            'O': 'oxide', 'S': 'sulfide', 'Se': 'selenide', 'Te': 'telluride',
            'N': 'nitride', 'P': 'phosphide', 'C': 'carbide', 'H': 'hydride'
        };

        if (knownAnions[sym]) return knownAnions[sym];

        // Algorithmic rule: apply -ide suffix
        if (name.endsWith('ine')) return name.replace(/ine$/, 'ide');
        if (name.endsWith('gen')) return name.replace(/gen$/, 'ide');
        if (name.endsWith('on')) return name.replace(/on$/, 'ide');
        if (name.endsWith('um')) return name.replace(/um$/, 'ide');
        if (name.endsWith('us')) return name.replace(/us$/, 'ide');

        return name + 'ide';
    }

    /**
     * Build polyatomic anion name
     */
    buildPolyatomicAnionName(mainElement, nonMetals, functionalGroups) {
        const hasOxygen = nonMetals.some(a => a.element.symbol === 'O');
        const hasHydrogen = nonMetals.some(a => a.element.symbol === 'H');

        // Check for known polyatomic ions first
        const knownName = this.detectKnownPolyatomicIon(mainElement.element, nonMetals);
        if (knownName) return knownName;

        // Oxyacids / oxyanions
        if (hasOxygen && hasHydrogen && mainElement.element.symbol !== 'O') {
            const central = mainElement;
            const oxygenCount = nonMetals.filter(a => a.element.symbol === 'O').length;
            const hydrogenCount = nonMetals.filter(a => a.element.symbol === 'H').length;

            return this.getOxyacidAnionName(central.element, oxygenCount, hydrogenCount);
        }

        // Default: use element name + -ide
        return this.getSimpleAnionName(mainElement.element);
    }

    /**
     * Detect known polyatomic ions algorithmically
     */
    detectKnownPolyatomicIon(centralElement, nonMetals) {
        const sym = centralElement.symbol;
        const oxygenCount = nonMetals.filter(a => a.element.symbol === 'O').length;
        const nitrogenCount = nonMetals.filter(a => a.element.symbol === 'N').length;
        const hydrogenCount = nonMetals.filter(a => a.element.symbol === 'H').length;
        const chlorineCount = nonMetals.filter(a => a.element.symbol === 'Cl').length;

        // Sulfur compounds
        if (sym === 'S' && oxygenCount === 4) return 'sulfate';
        if (sym === 'S' && oxygenCount === 3) return 'sulfite';
        if (sym === 'S' && oxygenCount === 4 && hydrogenCount === 1) return 'bisulfate';
        if (sym === 'S' && oxygenCount === 3 && hydrogenCount === 1) return 'bisulfite';

        // Nitrogen compounds
        if (sym === 'N' && oxygenCount === 3) return 'nitrate';
        if (sym === 'N' && oxygenCount === 2) return 'nitrite';

        // Phosphorus compounds
        if (sym === 'P' && oxygenCount === 4) return 'phosphate';
        if (sym === 'P' && oxygenCount === 3) return 'phosphite';

        // Carbon compounds
        if (sym === 'C' && oxygenCount === 3) return 'carbonate';
        if (sym === 'C' && oxygenCount === 3 && hydrogenCount === 1) return 'bicarbonate';

        // Chlorine compounds
        if (sym === 'Cl' && oxygenCount === 4) return 'perchlorate';
        if (sym === 'Cl' && oxygenCount === 3) return 'chlorate';
        if (sym === 'Cl' && oxygenCount === 2) return 'chlorite';
        if (sym === 'Cl' && oxygenCount === 1) return 'hypochlorite';

        // Bromine compounds
        if (sym === 'Br' && oxygenCount === 4) return 'perbromate';
        if (sym === 'Br' && oxygenCount === 3) return 'bromate';
        if (sym === 'Br' && oxygenCount === 2) return 'bromite';

        // Iodine compounds
        if (sym === 'I' && oxygenCount === 4) return 'periodate';
        if (sym === 'I' && oxygenCount === 3) return 'iodate';

        return null;
    }

    /**
     * Determine oxyacid anion name based on oxygen count
     * Uses IUPAC rules for oxyacids/oxyanions
     */
    getOxyacidAnionName(centralElement, oxygenCount, hydrogenCount) {
        const sym = centralElement.symbol;
        const baseName = centralElement.name.toLowerCase();

        // Known oxyacid/oxyanion patterns (use algorithm, not lookup)
        // Rule: Compare oxygen count to standard oxidation state

        // Map element to typical oxidation state
        const typicalOxState = {
            'S': 6,   // sulfur: -ate = SO4^2-, -ite = SO3^2-
            'N': 5,   // nitrogen: -ate = NO3^-, -ite = NO2^-
            'P': 5,   // phosphorus: -ate = PO4^3-, -ite = PO3^3-
            'C': 4,   // carbon: -ate = CO3^2- (carbonate)
            'Cl': 7,  // chlorine: -ate = ClO4^-, -ite = ClO3^-
            'B': 3,   // boron: -ate = BO3^3-, -ite = BO2^-
        };

        const typicalOxidation = typicalOxState[sym] || 4;

        // Estimate normal oxygen atoms based on oxidation state
        // Rule: max oxidation state ≈ oxygen atoms when element is in highest state
        const normalOxygen = Math.ceil(typicalOxidation / 2);

        // Suffixes follow IUPAC pattern:
        // per...ate (extra oxygen)
        // ...ate (normal oxygen)
        // ...ite (one less oxygen)
        // hypo...ite (two less oxygen)

        const baseForm = baseName.replace(/ine$/, '');

        if (oxygenCount > normalOxygen + 1) {
            // Per...ate: excess oxygen
            return `per${baseForm}ate`;
        } else if (oxygenCount === normalOxygen || oxygenCount === normalOxygen + 1) {
            // ...ate: standard or +1 oxygen
            return `${baseForm}ate`;
        } else if (oxygenCount === normalOxygen - 1) {
            // ...ite: one less oxygen
            return `${baseForm}ite`;
        } else if (oxygenCount < normalOxygen - 1) {
            // hypo...ite: two or more less oxygen
            return `hypo${baseForm}ite`;
        }

        return `${baseForm}ate`; // Default fallback
    }

    /**
     * Calculate oxidation state of an atom
     */
    calculateOxidationState(atom, allAtoms, bonds) {
        const bondedAtoms = this.getBondedAtoms(atom, allAtoms, bonds);
        let oxidationState = 0;

        bondedAtoms.forEach(({ atom: other, bond }) => {
            const enAtom = this.getElectronegativity(atom.element);
            const enOther = this.getElectronegativity(other.element);

            // Assume electrons go to more electronegative atom
            const bondOrder = bond.order || 1;

            if (enOther > enAtom) {
                // Electrons go to other atom
                oxidationState -= bondOrder;
            } else if (enOther < enAtom) {
                // Electrons stay with this atom
                oxidationState += bondOrder;
            }
            // If equal, no change
        });

        return oxidationState;
    }

    /**
     * Get bonded atoms for a given atom
     */
    getBondedAtoms(atom, allAtoms, bonds) {
        const bonded = [];
        bonds.forEach(bond => {
            const otherAtom = this.getBondPartner(atom, bond, allAtoms);
            if (otherAtom) {
                bonded.push({ atom: otherAtom, bond });
            }
        });
        return bonded;
    }

    /**
     * Get the other atom in a bond
     * Handles both object references and ID-based references
     */
    getBondPartner(atom, bond, allAtoms) {
        if (!bond) return null;

        const a1 = bond.a1;
        const a2 = bond.a2;

        // Helper to compare atoms (handles both object and ID references)
        const isSameAtom = (atomRef, targetAtom) => {
            if (!atomRef || !targetAtom) return false;
            if (atomRef === targetAtom) return true;
            if (atomRef.id && targetAtom.id && atomRef.id === targetAtom.id) return true;
            return false;
        };

        // Direct comparison
        if (isSameAtom(a1, atom)) return a2;
        if (isSameAtom(a2, atom)) return a1;

        // Resolve IDs if needed
        if (allAtoms) {
            const a1Obj = (typeof a1 === 'string') ? allAtoms.find(a => a.id === a1) : a1;
            const a2Obj = (typeof a2 === 'string') ? allAtoms.find(a => a.id === a2) : a2;

            if (isSameAtom(a1Obj, atom)) return a2Obj;
            if (isSameAtom(a2Obj, atom)) return a1Obj;
        }

        return null;
    }

    /**
     * Name organic compounds with IUPAC rules
     */
    nameOrganicCompound(atoms, bonds, composition) {
        // Common organic molecules
        if (composition['C'] === 1 && composition['H'] === 4) return 'methane';
        if (composition['C'] === 2 && composition['H'] === 6) return 'ethane';
        if (composition['C'] === 3 && composition['H'] === 8) return 'propane';
        if (composition['C'] === 4 && composition['H'] === 10) return 'butane';
        if (composition['C'] === 5 && composition['H'] === 12) return 'pentane';
        if (composition['C'] === 6 && composition['H'] === 14) return 'hexane';

        // Water (edge case)
        if (composition['H'] === 2 && composition['O'] === 1) return 'water';

        // Find carbon skeleton
        const carbons = atoms.filter(a => a.element.symbol === 'C');

        // If no carbon, not organic
        if (carbons.length === 0) {
            return this.generateFormulaBasedName(atoms, composition);
        }

        // Trace the main carbon chain
        const carbonChain = this.traceMainChain(carbons, atoms, bonds);
        if (carbonChain.length === 0) carbonChain.push(carbons[0]);

        // Build main chain name
        const chainName = this.buildAlkaneChainName(carbonChain.length);

        // Identify functional groups
        const functionalGroups = this.identifyFunctionalGroups(atoms, atoms, bonds);

        // Build full name with functional groups
        return this.buildOrganicName(chainName, functionalGroups, carbonChain);
    }

    /**
     * Trace the longest carbon chain
     */
    traceMainChain(carbons, allAtoms, bonds) {
        if (carbons.length === 0) return [];
        if (carbons.length === 1) return carbons;

        // DFS to find longest chain
        let longestChain = [];

        const dfs = (atom, visited, chain) => {
            visited.add(atom.id);
            chain.push(atom);

            if (chain.length > longestChain.length) {
                longestChain = [...chain];
            }

            const bonded = this.getBondedAtoms(atom, allAtoms, bonds);
            bonded.forEach(({ atom: other }) => {
                if (other.element.symbol === 'C' && !visited.has(other.id)) {
                    dfs(other, visited, chain);
                }
            });

            chain.pop();
            visited.delete(atom.id);
        };

        dfs(carbons[0], new Set(), []);
        return longestChain;
    }

    /**
     * Get alkane chain name from carbon count
     */
    buildAlkaneChainName(carbonCount) {
        const chainNames = {
            1: 'methane', 2: 'ethane', 3: 'propane', 4: 'butane', 5: 'pentane',
            6: 'hexane', 7: 'heptane', 8: 'octane', 9: 'nonane', 10: 'decane'
        };

        if (chainNames[carbonCount]) return chainNames[carbonCount];

        // Algorithmic for longer chains
        const prefixes = {
            11: 'undecane', 12: 'dodecane', 13: 'tridecane', 14: 'tetradecane',
            15: 'pentadecane', 16: 'hexadecane', 17: 'heptadecane', 18: 'octadecane',
            19: 'nonadecane', 20: 'icosane'
        };

        return prefixes[carbonCount] || `C${carbonCount}alkane`;
    }

    /**
     * Identify functional groups in molecule
     */
    identifyFunctionalGroups(atoms, allAtoms, bonds) {
        const groups = {};

        // Detect alcohols: C-OH
        atoms.forEach(atom => {
            if (atom.element.symbol === 'O') {
                const bonded = this.getBondedAtoms(atom, allAtoms, bonds);
                const hasH = bonded.some(b => b.atom.element.symbol === 'H');
                const hasC = bonded.some(b => b.atom.element.symbol === 'C');

                if (hasH && hasC) {
                    groups['alcohol'] = (groups['alcohol'] || 0) + 1;
                }
            }
        });

        // Detect amines: C-NH2 / C-NR2
        atoms.forEach(atom => {
            if (atom.element.symbol === 'N') {
                groups['amine'] = (groups['amine'] || 0) + 1;
            }
        });

        return groups;
    }

    /**
     * Build full organic molecule name
     */
    buildOrganicName(chainName, functionalGroups, chain) {
        // If just alkane, return chain name
        if (Object.keys(functionalGroups).length === 0) {
            return chainName;
        }

        // Add functional group information
        const groupNames = Object.keys(functionalGroups).sort();
        const modifiedName = chainName.replace(/ane$/, '');

        if (functionalGroups['alcohol'] > 0) {
            const suffix = functionalGroups['alcohol'] > 1 ? 'diol' : 'ol';
            return `${modifiedName}${suffix}`;
        }

        return chainName;
    }

    /**
     * Name inorganic covalent compounds
     */
    nameInorganicCovalent(atoms, bonds, composition) {
        // Sort by electronegativity
        const sorted = atoms.slice().sort((a, b) => {
            const enA = this.getElectronegativity(a.element);
            const enB = this.getElectronegativity(b.element);
            return enA - enB; // Less electronegative first
        });

        if (sorted.length < 2) {
            return this.generateFormulaBasedName(atoms, composition);
        }

        // Name: prefix + first element, prefix + second element with -ide
        const first = sorted[0];
        const second = sorted[sorted.length - 1];

        const firstCount = atoms.filter(a => a.element.symbol === first.element.symbol).length;
        const secondCount = atoms.filter(a => a.element.symbol === second.element.symbol).length;

        const firstName = firstCount > 1 ?
            `${this.numericPrefixes[firstCount]}${first.element.name.toLowerCase()}` :
            first.element.name.toLowerCase();

        const secondName = secondCount > 1 ?
            `${this.numericPrefixes[secondCount]}${this.getSimpleAnionName(second.element)}` :
            this.getSimpleAnionName(second.element);

        return `${firstName} ${secondName}`;
    }

    /**
     * Generate formula-based name as fallback
     */
    generateFormulaBasedName(atoms, composition) {
        // Build Hill system formula (C first if present, then H if present, then alphabetical)
        let formula = '';

        if (composition['C']) {
            formula += 'C' + (composition['C'] > 1 ? composition['C'] : '');
        }
        if (composition['H']) {
            formula += 'H' + (composition['H'] > 1 ? composition['H'] : '');
        }

        const otherElements = Object.entries(composition)
            .filter(([sym]) => sym !== 'C' && sym !== 'H')
            .sort(([a], [b]) => a.localeCompare(b));

        otherElements.forEach(([sym, count]) => {
            formula += sym + (count > 1 ? count : '');
        });

        return `Compound ${formula}`;
    }

    /**
     * Convert number to Roman numeral
     */
    toRomanNumeral(num) {
        const romanMap = [
            { val: 8, sym: 'VIII' }, { val: 5, sym: 'V' }, { val: 4, sym: 'IV' },
            { val: 1, sym: 'I' }
        ];

        let result = '';
        let n = num;

        romanMap.forEach(({ val, sym }) => {
            while (n >= val) {
                result += sym;
                n -= val;
            }
        });

        return result;
    }

    /**
     * Build formula string from atoms
     */
    buildFormulaString(atoms) {
        const counts = {};
        atoms.forEach(a => {
            counts[a.element.symbol] = (counts[a.element.symbol] || 0) + 1;
        });

        let formula = '';
        Object.entries(counts)
            .sort(([a], [b]) => a.localeCompare(b))
            .forEach(([sym, count]) => {
                formula += sym + (count > 1 ? count : '');
            });

        return formula;
    }
}
