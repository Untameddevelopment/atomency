#!/usr/bin/env node
/**
 * Verify VSEPR Physics Engine
 * Tests that Coulomb repulsion on a unit sphere produces correct molecular angles
 */

class VSEPRPhysics {
    constructor() {
        this.LONE_PAIR_REPULSION = 1.20;
        this.RELAXATION_STEPS = 2000;
    }

    _solveDomainPositions(total, bonding, lone) {
        const pos = [];
        const types = [];
        for (let i = 0; i < total; i++) {
            types.push(i < bonding ? 'bond' : 'lone');
            if (total === 1) { pos.push({x:1,y:0,z:0}); continue; }
            const frac = i / (total - 1);
            const y = 1 - 2 * frac;
            const r = Math.sqrt(Math.max(0, 1 - y * y));
            const theta = Math.PI * (1 + Math.sqrt(5)) * i;
            pos.push({ x: r * Math.cos(theta), y, z: r * Math.sin(theta) });
        }

        const vels = pos.map(() => ({x:0,y:0,z:0}));
        const damping = 0.92;
        const loneK = this.LONE_PAIR_REPULSION;

        for (let iter = 0; iter < this.RELAXATION_STEPS; iter++) {
            const dt = 0.08 / (1 + iter * 0.004);
            for (let i = 0; i < total; i++) {
                let fx=0, fy=0, fz=0;
                for (let j = 0; j < total; j++) {
                    if (i === j) continue;
                    const dx = pos[i].x - pos[j].x;
                    const dy = pos[i].y - pos[j].y;
                    const dz = pos[i].z - pos[j].z;
                    const dist2 = dx*dx + dy*dy + dz*dz;
                    const dist = Math.sqrt(dist2);
                    if (dist < 1e-6) continue;
                    let k = 1.0;
                    if (types[i]==='lone') k *= loneK;
                    if (types[j]==='lone') k *= loneK;
                    const mag = k / dist2;
                    fx += (dx/dist)*mag;
                    fy += (dy/dist)*mag;
                    fz += (dz/dist)*mag;
                }
                vels[i].x = (vels[i].x + fx*dt) * damping;
                vels[i].y = (vels[i].y + fy*dt) * damping;
                vels[i].z = (vels[i].z + fz*dt) * damping;
            }
            for (let i = 0; i < total; i++) {
                pos[i].x += vels[i].x * dt;
                pos[i].y += vels[i].y * dt;
                pos[i].z += vels[i].z * dt;
                const len = Math.sqrt(pos[i].x**2 + pos[i].y**2 + pos[i].z**2);
                if (len > 1e-8) { pos[i].x/=len; pos[i].y/=len; pos[i].z/=len; }
            }
        }
        return pos;
    }
}

function angleBetween(a, b) {
    const dot = a.x*b.x + a.y*b.y + a.z*b.z;
    return Math.acos(Math.max(-1, Math.min(1, dot))) * 180 / Math.PI;
}

function avgBondAngle(positions, bondingCount) {
    let sum = 0, count = 0;
    for (let i = 0; i < bondingCount; i++) {
        for (let j = i + 1; j < bondingCount; j++) {
            sum += angleBetween(positions[i], positions[j]);
            count++;
        }
    }
    return count > 0 ? sum / count : 0;
}

function minBondAngle(positions, bondingCount) {
    let min = 360;
    for (let i = 0; i < bondingCount; i++) {
        for (let j = i + 1; j < bondingCount; j++) {
            min = Math.min(min, angleBetween(positions[i], positions[j]));
        }
    }
    return min;
}

const physics = new VSEPRPhysics();

const tests = [
    { name: 'CO2 (Linear)',                bonds: 2, lone: 0, metric: 'avg', expected: 180,   tolerance: 2 },
    { name: 'BF3 (Trigonal Planar)',        bonds: 3, lone: 0, metric: 'avg', expected: 120,   tolerance: 2 },
    { name: 'CH4 (Tetrahedral)',            bonds: 4, lone: 0, metric: 'avg', expected: 109.5, tolerance: 2 },
    { name: 'NH3 (Trig. Pyramidal)',        bonds: 3, lone: 1, metric: 'avg', expected: 107,   tolerance: 4 },
    { name: 'H2O (Bent)',                   bonds: 2, lone: 2, metric: 'avg', expected: 104.5, tolerance: 5 },
    { name: 'SO2 (Bent 3-domain)',          bonds: 2, lone: 1, metric: 'avg', expected: 117,   tolerance: 6 },
    { name: 'PCl5 (Trig. Bipyramidal)',     bonds: 5, lone: 0, metric: 'min', expected: 90,    tolerance: 5 },
    { name: 'SF6 (Octahedral)',             bonds: 6, lone: 0, metric: 'min', expected: 90,    tolerance: 5 },
];

console.log('=== VSEPR Physics Verification ===\n');
let passed = 0, failed = 0;

tests.forEach(t => {
    const total = t.bonds + t.lone;
    const positions = physics._solveDomainPositions(total, t.bonds, t.lone);
    const avg = avgBondAngle(positions, t.bonds);
    const min = minBondAngle(positions, t.bonds);
    const actual = t.metric === 'min' ? min : avg;
    const diff = Math.abs(actual - t.expected);
    const ok = diff <= t.tolerance;

    console.log(`[${ok ? 'PASS' : 'FAIL'}] ${t.name}`);
    console.log(`       Expected ${t.metric}: ~${t.expected}°  Got: ${actual.toFixed(1)}°  (diff: ${diff.toFixed(1)}°)`);
    console.log(`       Avg: ${avg.toFixed(1)}°  Min: ${min.toFixed(1)}°  Domains: ${total} (${t.bonds}B + ${t.lone}LP)\n`);

    if (ok) passed++; else failed++;
});

console.log(`Results: ${passed}/${tests.length} passed`);
if (failed > 0) { console.error('Some tests failed.'); process.exit(1); }
else { console.log('All tests passed! Pure physics produces correct VSEPR angles.'); process.exit(0); }
