/**
 * Analytics Tracking Tables
 *
 * Tracks:
 * - Page views
 * - Feature usage (periodic table, molecule builder, VSEPR)
 * - Session duration and engagement
 */
module.exports = {
  name: 'create_analytics',
  up: async (client) => {
    // Main analytics events table
    await client.query(`
      CREATE TABLE IF NOT EXISTS analytics_events (
        id SERIAL PRIMARY KEY,
        event_type VARCHAR(100) NOT NULL,
        event_data JSONB,
        visitor_id VARCHAR(255),
        user_agent TEXT,
        ip_address VARCHAR(50),
        referrer TEXT,
        page_path VARCHAR(500),
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Indexes for fast queries
    await client.query(`CREATE INDEX IF NOT EXISTS idx_analytics_event_type ON analytics_events(event_type)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_analytics_created_at ON analytics_events(created_at DESC)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_analytics_visitor_id ON analytics_events(visitor_id)`);

    console.log('Analytics tables created successfully');
  }
};
