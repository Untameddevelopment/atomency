/**
 * Verify algorithmic phase prediction against known experimental data.
 * Tests: CH4, NH3, Cl2, CO2, H2O, ethanol, HCl, NaCl at various T/P.
 * All phase boundaries are calculated algorithmically — NO molecule-specific lookups.
 */

// Mock minimal element data
const elements = {
    H:  { symbol: 'H',  number: 1,  atomic_mass: 1.008,  electronegativity_pauling: 2.20, category: 'diatomic nonmetal', group: 1, period: 1 },
    C:  { symbol: 'C',  number: 6,  atomic_mass: 12.011, electronegativity_pauling: 2.55, category: 'polyatomic nonmetal', group: 14, period: 2 },
    N:  { symbol: 'N',  number: 7,  atomic_mass: 14.007, electronegativity_pauling: 3.04, category: 'diatomic nonmetal', group: 15, period: 2 },
    O:  { symbol: 'O',  number: 8,  atomic_mass: 15.999, electronegativity_pauling: 3.44, category: 'diatomic nonmetal', group: 16, period: 2 },
    Cl: { symbol: 'Cl', number: 17, atomic_mass: 35.45,  electronegativity_pauling: 3.16, category: 'diatomic nonmetal', group: 17, period: 3 },
    Na: { symbol: 'Na', number: 11, atomic_mass: 22.990, electronegativity_pauling: 0.93, category: 'alkali metal', group: 1, period: 3 },
    Ca: { symbol: 'Ca', number: 20, atomic_mass: 40.078, electronegativity_pauling: 1.00, category: 'alkaline earth metal', group: 2, period: 4 },
    Fe: { symbol: 'Fe', number: 26, atomic_mass: 55.845, electronegativity_pauling: 1.83, category: 'transition metal', group: 8, period: 4 },
    Mg: { symbol: 'Mg', number: 12, atomic_mass: 24.305, electronegativity_pauling: 1.31, category: 'alkaline earth metal', group: 2, period: 3 },
    Pb: { symbol: 'Pb', number: 82, atomic_mass: 207.2,  electronegativity_pauling: 1.87, category: 'post-transition metal', group: 14, period: 6 },
    S:  { symbol: 'S',  number: 16, atomic_mass: 32.06,  electronegativity_pauling: 2.58, category: 'polyatomic nonmetal', group: 16, period: 3 },
    F:  { symbol: 'F',  number: 9,  atomic_mass: 18.998, electronegativity_pauling: 3.98, category: 'diatomic nonmetal', group: 17, period: 2 },
};

// Load engine
const fs = require('fs');
global.window = {};
const engineCode = fs.readFileSync('public/js/alchemist-engine.js', 'utf8');
eval(engineCode);
const ChemistryEngine = window.ChemistryEngine;

const engine = new ChemistryEngine();
engine.elements = Object.values(elements);

// Helper: build molecule from atom specs and bonds
function buildMolecule(atomSpecs, bondSpecs) {
    engine.atoms = [];
    engine.bonds = [];

    atomSpecs.forEach((spec, i) => {
        engine.atoms.push({
            id: `a${i}`,
            element: elements[spec],
            x: i * 80,
            y: 300,
            oxidationState: 0,
            formalCharge: 0,
            partialCharge: 0,
            lonePairs: 0
        });
    });

    bondSpecs.forEach(([i1, i2, order, isIonic]) => {
        engine.bonds.push({
            id: `a${i1}-a${i2}`,
            a1: engine.atoms[i1],
            a2: engine.atoms[i2],
            type: isIonic ? 'ionic' : (order === 3 ? 'triple' : order === 2 ? 'double' : 'single'),
            order: order,
            isIonic: !!isIonic
        });
    });

    // Calculate lone pairs
    engine.atoms.forEach(atom => {
        const bonded = engine.getBondedAtoms(atom);
        const bondElectrons = bonded.reduce((s, b) => s + b.bond.order, 0);
        const valence = engine.getValenceElectrons(atom.element);
        atom.lonePairs = Math.max(0, Math.floor((valence - bondElectrons) / 2));
    });

    const counts = engine.countElements(engine.atoms);
    return { atoms: engine.atoms, counts };
}

function testPhase(name, atomSpecs, bondSpecs, temp, pressure, expectedState, actualBp, actualMp) {
    engine.temperature = temp;
    engine.pressure = pressure;

    const { atoms, counts } = buildMolecule(atomSpecs, bondSpecs);
    const state = engine.predictState(atoms, counts, 80);
    const pd = engine._lastPhaseData || {};

    const pass = state === expectedState;
    const status = pass ? '  PASS' : '**FAIL**';

    console.log(`${status} | ${name.padEnd(32)} | T=${String(temp).padEnd(4)}K P=${String(pressure).padEnd(5)}atm | Got: ${state.padEnd(13)} | Expected: ${expectedState.padEnd(13)} | Est Tb=${String(pd.Tb_normal || '?').padEnd(5)}K (act ${actualBp}K) | Est Tm=${String(pd.Tm_normal || '?').padEnd(5)}K (act ${actualMp}K)`);
    return pass;
}

console.log('='.repeat(170));
console.log('ALGORITHMIC PHASE PREDICTION VERIFICATION — Improved Algorithm');
console.log('='.repeat(170));

let passed = 0, total = 0;

// ── CH4: bp=111K, mp=91K — nonpolar, London forces only ──
total++; if (testPhase('CH4 at 200K', ['C','H','H','H','H'], [[0,1,1],[0,2,1],[0,3,1],[0,4,1]], 200, 1.0, 'Gas', 111, 91)) passed++;
total++; if (testPhase('CH4 at 80K', ['C','H','H','H','H'], [[0,1,1],[0,2,1],[0,3,1],[0,4,1]], 80, 1.0, 'Solid', 111, 91)) passed++;
total++; if (testPhase('CH4 at 100K', ['C','H','H','H','H'], [[0,1,1],[0,2,1],[0,3,1],[0,4,1]], 100, 1.0, 'Liquid', 111, 91)) passed++;

// ── NH3: bp=239.7K, mp=195.5K — H-bonding ──
total++; if (testPhase('NH3 at 250K', ['N','H','H','H'], [[0,1,1],[0,2,1],[0,3,1]], 250, 1.0, 'Gas', 240, 196)) passed++;
total++; if (testPhase('NH3 at 220K', ['N','H','H','H'], [[0,1,1],[0,2,1],[0,3,1]], 220, 1.0, 'Liquid', 240, 196)) passed++;
total++; if (testPhase('NH3 at 150K', ['N','H','H','H'], [[0,1,1],[0,2,1],[0,3,1]], 150, 1.0, 'Solid', 240, 196)) passed++;

// ── Cl2: bp=239.1K, mp=171.6K — nonpolar diatomic ──
total++; if (testPhase('Cl2 at 298K', ['Cl','Cl'], [[0,1,1]], 298, 1.0, 'Gas', 239, 172)) passed++;
total++; if (testPhase('Cl2 at 200K', ['Cl','Cl'], [[0,1,1]], 200, 1.0, 'Liquid', 239, 172)) passed++;
total++; if (testPhase('Cl2 at 150K', ['Cl','Cl'], [[0,1,1]], 150, 1.0, 'Solid', 239, 172)) passed++;

// ── H2O: bp=373K, mp=273K — strong H-bonding ──
total++; if (testPhase('H2O at 298K', ['O','H','H'], [[0,1,1],[0,2,1]], 298, 1.0, 'Liquid', 373, 273)) passed++;
total++; if (testPhase('H2O at 400K', ['O','H','H'], [[0,1,1],[0,2,1]], 400, 1.0, 'Gas', 373, 273)) passed++;
total++; if (testPhase('H2O at 200K', ['O','H','H'], [[0,1,1],[0,2,1]], 200, 1.0, 'Solid', 373, 273)) passed++;

// ── CO2: sublimes at 1atm (~195K), no liquid phase below 5.1 atm ──
total++; if (testPhase('CO2 at 298K 1atm', ['C','O','O'], [[0,1,2],[0,2,2]], 298, 1.0, 'Gas', 195, 217)) passed++;
total++; if (testPhase('CO2 at 100K 1atm', ['C','O','O'], [[0,1,2],[0,2,2]], 100, 1.0, 'Solid', 195, 217)) passed++;
total++; if (testPhase('CO2 at 250K 1atm (sublimed)', ['C','O','O'], [[0,1,2],[0,2,2]], 250, 1.0, 'Gas', 195, 217)) passed++;

// ── Ethanol (C2H5OH): bp=351K, mp=159K — H-bonding with rotatable bonds ──
// Ethanol: C(0)-C(1), C(0)-H(2), C(0)-H(3), C(0)-H(4), C(1)-O(5), C(1)-H(6), C(1)-H(7), O(5)-H(8)
const ethanolAtoms = ['C','C','H','H','H','O','H','H','H'];
const ethanolBonds = [[0,1,1],[0,2,1],[0,3,1],[0,4,1],[1,5,1],[1,6,1],[1,7,1],[5,8,1]];
total++; if (testPhase('Ethanol at 298K', ethanolAtoms, ethanolBonds, 298, 1.0, 'Liquid', 351, 159)) passed++;
total++; if (testPhase('Ethanol at 100K', ethanolAtoms, ethanolBonds, 100, 1.0, 'Solid', 351, 159)) passed++;
total++; if (testPhase('Ethanol at 400K', ethanolAtoms, ethanolBonds, 400, 1.0, 'Gas', 351, 159)) passed++;

// ── PRESSURE TESTS ──
// H2O at high pressure: higher boiling point
total++; if (testPhase('H2O at 400K 5atm', ['O','H','H'], [[0,1,1],[0,2,1]], 400, 5.0, 'Liquid', 373, 273)) passed++;

// CO2 at high pressure: liquid phase appears above triple point pressure
// CO2 critical point: Tc≈304K, Pc≈73atm
total++; if (testPhase('CO2 at 298K 100atm (liquid)', ['C','O','O'], [[0,1,2],[0,2,2]], 298, 100, 'Liquid', 195, 217)) passed++;
total++; if (testPhase('CO2 at 310K 100atm (supercrit)', ['C','O','O'], [[0,1,2],[0,2,2]], 310, 100, 'Supercritical', 195, 217)) passed++;

// NaCl: ionic, solid at room temp (Tm≈1074K)
total++; if (testPhase('NaCl at 298K', ['Na','Cl'], [[0,1,1,true]], 298, 1.0, 'Solid', 1738, 1074)) passed++;
total++; if (testPhase('NaCl at 1200K', ['Na','Cl'], [[0,1,1,true]], 1200, 1.0, 'Liquid', 1738, 1074)) passed++;

// SO2: bp=263K, mp=200K — polar bent molecule
total++; if (testPhase('SO2 at 298K', ['S','O','O'], [[0,1,2],[0,2,2]], 298, 1.0, 'Gas', 263, 200)) passed++;

// HF: bp=292.5K, mp=189.6K — very strong H-bonding
total++; if (testPhase('HF at 298K', ['H','F'], [[0,1,1]], 298, 1.0, 'Gas', 293, 190)) passed++;

console.log('='.repeat(170));
console.log(`Results: ${passed}/${total} passed (${Math.round(passed/total*100)}%)`);

// Print phase boundary estimates for review
console.log('\n--- Phase Boundary Estimates (for review) ---');
const moleculesForReview = [
    { name: 'CH4', specs: ['C','H','H','H','H'], bonds: [[0,1,1],[0,2,1],[0,3,1],[0,4,1]], realBp: 111, realMp: 91 },
    { name: 'NH3', specs: ['N','H','H','H'], bonds: [[0,1,1],[0,2,1],[0,3,1]], realBp: 240, realMp: 196 },
    { name: 'H2O', specs: ['O','H','H'], bonds: [[0,1,1],[0,2,1]], realBp: 373, realMp: 273 },
    { name: 'Cl2', specs: ['Cl','Cl'], bonds: [[0,1,1]], realBp: 239, realMp: 172 },
    { name: 'CO2', specs: ['C','O','O'], bonds: [[0,1,2],[0,2,2]], realBp: 195, realMp: 217 },
    { name: 'Ethanol', specs: ethanolAtoms, bonds: ethanolBonds, realBp: 351, realMp: 159 },
    { name: 'NaCl', specs: ['Na','Cl'], bonds: [[0,1,1,true]], realBp: 1738, realMp: 1074 },
];

moleculesForReview.forEach(m => {
    engine.temperature = 298;
    engine.pressure = 1.0;
    const { atoms, counts } = buildMolecule(m.specs, m.bonds);
    engine.predictState(atoms, counts, 80);
    const pd = engine._lastPhaseData;
    const tbErr = Math.round(Math.abs(pd.Tb_normal - m.realBp) / m.realBp * 100);
    const tmErr = Math.round(Math.abs(pd.Tm_normal - m.realMp) / m.realMp * 100);
    const sublimes = pd.Tm_normal > pd.Tb_normal ? ' [SUBLIMES]' : '';
    console.log(`${m.name.padEnd(8)} | Est Tb=${String(pd.Tb_normal).padEnd(5)}K (real ${String(m.realBp).padEnd(4)}K, err ${String(tbErr).padEnd(2)}%) | Est Tm=${String(pd.Tm_normal).padEnd(5)}K (real ${String(m.realMp).padEnd(4)}K, err ${String(tmErr).padEnd(2)}%) | Tc=${pd.Tc}K Pc=${pd.Pc}atm${sublimes}`);
});

if (passed < total) {
    process.exit(1);
}
