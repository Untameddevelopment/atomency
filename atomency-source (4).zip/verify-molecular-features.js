/**
 * VERIFICATION SCRIPT - Molecular Features System
 * Tests stereochemistry, isotopes, expanded octets, and ring detection
 */

const tests = [];
let passed = 0;
let failed = 0;

function test(name, fn) {
    try {
        fn();
        tests.push({ name, status: 'PASS', error: null });
        passed++;
        console.log(`✓ ${name}`);
    } catch (error) {
        tests.push({ name, status: 'FAIL', error: error.message });
        failed++;
        console.error(`✗ ${name}: ${error.message}`);
    }
}

function assert(condition, message) {
    if (!condition) throw new Error(message || 'Assertion failed');
}

// ============================================================================
// ISOTOPE SYSTEM TESTS
// ============================================================================

test('IsotopeSystem: Can create instance', () => {
    const engine = { elements: [] };
    const isotopes = new IsotopeSystem(engine);
    assert(isotopes !== undefined, 'IsotopeSystem instance created');
});

test('IsotopeSystem: Calculates isotopic mass', () => {
    const engine = { elements: [] };
    const isotopes = new IsotopeSystem(engine);

    // Carbon-12: 6 protons, 6 neutrons
    const mass12 = isotopes.calculateIsotopicMass(6, 6);
    assert(mass12 > 11 && mass12 < 13, `Carbon-12 mass calculated: ${mass12}`);

    // Carbon-14: 6 protons, 8 neutrons
    const mass14 = isotopes.calculateIsotopicMass(6, 8);
    assert(mass14 > 13 && mass14 < 15, `Carbon-14 mass calculated: ${mass14}`);
});

test('IsotopeSystem: Detects realistic isotopes', () => {
    const engine = { elements: [] };
    const isotopes = new IsotopeSystem(engine);

    // Carbon-12 should be realistic
    assert(isotopes.isRealisticIsotope(6, 12, 12), 'C-12 is realistic');

    // Carbon-5 should NOT be realistic (too few neutrons)
    assert(!isotopes.isRealisticIsotope(6, 5, 5), 'C-5 is not realistic');
});

test('IsotopeSystem: Gets default isotope', () => {
    const engine = { elements: [] };
    const isotopes = new IsotopeSystem(engine);

    const element = { number: 6, symbol: 'C', atomicMass: 12.011 };
    const defaultIso = isotopes.getDefaultIsotope(element);
    assert(defaultIso.massNumber === 12, `Default C isotope is C-12: ${defaultIso.massNumber}`);
});

// ============================================================================
// STEREOCHEMISTRY SYSTEM TESTS
// ============================================================================

test('StereochemistrySystem: Can create instance', () => {
    const engine = { elements: [] };
    const stereo = new StereochemistrySystem(engine);
    assert(stereo !== undefined, 'StereochemistrySystem instance created');
});

test('StereochemistrySystem: Detects chiral atoms correctly', () => {
    const engine = { elements: [] };
    const stereo = new StereochemistrySystem(engine);

    const carbon = { symbol: 'C', number: 6 };
    const nitrogen = { symbol: 'N', number: 7 };
    const hydrogen = { symbol: 'H', number: 1 };

    assert(stereo.canBeChiral({ element: carbon }), 'Carbon can be chiral');
    assert(stereo.canBeChiral({ element: nitrogen }), 'Nitrogen can be chiral');
    assert(!stereo.canBeChiral({ element: hydrogen }), 'Hydrogen cannot be chiral');
});

test('StereochemistrySystem: Gets neighbors from bonds', () => {
    const atom1 = { id: 'a1', element: { symbol: 'C' } };
    const atom2 = { id: 'a2', element: { symbol: 'H' } };
    const atom3 = { id: 'a3', element: { symbol: 'O' } };

    const bonds = [
        { a1: atom1, a2: atom2, order: 1 },
        { a1: atom1, a2: atom3, order: 1 }
    ];

    const engine = { elements: [] };
    const stereo = new StereochemistrySystem(engine);

    const neighbors = stereo.getNeighbors(atom1, bonds);
    assert(neighbors.length === 2, `Found 2 neighbors: ${neighbors.length}`);
    assert(neighbors.includes(atom2), 'Neighbor includes atom2');
    assert(neighbors.includes(atom3), 'Neighbor includes atom3');
});

test('StereochemistrySystem: Counts stereoisomers', () => {
    const engine = { elements: [] };
    const stereo = new StereochemistrySystem(engine);

    // Mock atoms and bonds
    const atoms = [];
    const bonds = [];

    const result = stereo.countStereoisomers(atoms, bonds);
    assert(result.totalStereoisomers === 1, `No chiral centers = 1 stereoisomer: ${result.totalStereoisomers}`);
});

// ============================================================================
// EXPANDED OCTET SYSTEM TESTS
// ============================================================================

test('ExpandedOctetSystem: Can create instance', () => {
    const engine = { elements: [] };
    const octet = new ExpandedOctetSystem(engine);
    assert(octet !== undefined, 'ExpandedOctetSystem instance created');
});

test('ExpandedOctetSystem: Identifies period 3+ elements', () => {
    const engine = { elements: [] };
    const octet = new ExpandedOctetSystem(engine);

    const H = { period: 1, group: 1, symbol: 'H' };
    const C = { period: 2, group: 14, symbol: 'C' };
    const P = { period: 3, group: 15, symbol: 'P' };
    const S = { period: 3, group: 16, symbol: 'S' };

    assert(!octet.canFormExpandedOctet(H), 'H cannot form expanded octet');
    assert(!octet.canFormExpandedOctet(C), 'C cannot form expanded octet');
    assert(octet.canFormExpandedOctet(P), 'P can form expanded octet');
    assert(octet.canFormExpandedOctet(S), 'S can form expanded octet');
});

test('ExpandedOctetSystem: Gets correct coordination numbers', () => {
    const engine = { elements: [] };
    const octet = new ExpandedOctetSystem(engine);

    const P = { period: 3, group: 15, symbol: 'P' };
    const S = { period: 3, group: 16, symbol: 'S' };
    const C = { period: 2, group: 14, symbol: 'C' };

    assert(octet.getMaxCoordinationNumber(P) === 5, `P max coordination = 5: ${octet.getMaxCoordinationNumber(P)}`);
    assert(octet.getMaxCoordinationNumber(S) === 6, `S max coordination = 6: ${octet.getMaxCoordinationNumber(S)}`);
    assert(octet.getMaxCoordinationNumber(C) === 4, `C max coordination = 4: ${octet.getMaxCoordinationNumber(C)}`);
});

// ============================================================================
// RING DETECTION SYSTEM TESTS
// ============================================================================

test('RingDetectionSystem: Can create instance', () => {
    const engine = { elements: [] };
    const rings = new RingDetectionSystem(engine);
    assert(rings !== undefined, 'RingDetectionSystem instance created');
});

test('RingDetectionSystem: Builds adjacency list correctly', () => {
    const engine = { elements: [] };
    const rings = new RingDetectionSystem(engine);

    const a1 = { id: '1' };
    const a2 = { id: '2' };
    const a3 = { id: '3' };

    const atoms = [a1, a2, a3];
    const bonds = [
        { a1, a2 },
        { a2, a3 }
    ];

    const adj = rings.buildAdjacencyList(atoms, bonds);
    assert(adj.get('1').length === 1, `Node 1 has 1 neighbor`);
    assert(adj.get('2').length === 2, `Node 2 has 2 neighbors`);
    assert(adj.get('3').length === 1, `Node 3 has 1 neighbor`);
});

test('RingDetectionSystem: Classifies ring by size', () => {
    const engine = { elements: [] };
    const rings = new RingDetectionSystem(engine);

    const ring3 = [1, 2, 3];
    const ring6 = [1, 2, 3, 4, 5, 6];

    const class3 = rings.classifyRing(ring3);
    const class6 = rings.classifyRing(ring6);

    assert(class3.size === 3, `3-membered ring classified`);
    assert(class6.size === 6, `6-membered ring classified`);
});

// ============================================================================
// STRUCTURE COUNTER TESTS
// ============================================================================

test('StructureCounter: Can create instance', () => {
    const engine = { elements: [] };
    const counter = new StructureCounter(engine);
    assert(counter !== undefined, 'StructureCounter instance created');
});

test('StructureCounter: Calculates basic structure count', () => {
    const engine = { elements: [] };
    const counter = new StructureCounter(engine);

    const atoms = [];
    const bonds = [];

    const result = counter.calculateTotalStructures(atoms, bonds);
    assert(result.total >= 1, `Total structures >= 1: ${result.total}`);
    assert(result.breakdown !== undefined, 'Breakdown included');
});

// ============================================================================
// ENGINE INTEGRATION TESTS
// ============================================================================

test('Engine Enhancement: enhanceEngineWithMolecularFeatures exists', () => {
    assert(typeof enhanceEngineWithMolecularFeatures === 'function',
        'enhanceEngineWithMolecularFeatures is a function');
});

test('Engine Enhancement: Adds systems to engine', () => {
    const engine = { elements: [], atoms: [], bonds: [] };
    enhanceEngineWithMolecularFeatures(engine);

    assert(engine.isotopes !== undefined, 'isotopes system added');
    assert(engine.stereochemistry !== undefined, 'stereochemistry system added');
    assert(engine.expandedOctet !== undefined, 'expandedOctet system added');
    assert(engine.rings !== undefined, 'rings system added');
    assert(engine.structureCounter !== undefined, 'structureCounter system added');
});

// ============================================================================
// SUMMARY
// ============================================================================

console.log('\n' + '='.repeat(60));
console.log(`MOLECULAR FEATURES VERIFICATION COMPLETE`);
console.log('='.repeat(60));
console.log(`✓ Passed: ${passed}`);
console.log(`✗ Failed: ${failed}`);
console.log(`Total:   ${passed + failed}`);

if (failed === 0) {
    console.log('\n🎉 ALL TESTS PASSED! Molecular features system is working correctly.');
} else {
    console.log(`\n⚠️  ${failed} test(s) failed. Review errors above.`);
}

// Export results
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { tests, passed, failed };
}
