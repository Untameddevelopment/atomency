// Verification script: Test VSEPR geometry calculations
// Simulates the engine's bond/atom structure to verify the fix

// Mock the VSEPRCalculator
class VSEPRCalculator {
    constructor() {
        this.geometryTable = {
            '2-0': { electron: 'Linear', molecular: 'Linear', angle: 180 },
            '3-0': { electron: 'Trigonal Planar', molecular: 'Trigonal Planar', angle: 120 },
            '2-1': { electron: 'Trigonal Planar', molecular: 'Bent', angle: 117 },
            '4-0': { electron: 'Tetrahedral', molecular: 'Tetrahedral', angle: 109.5 },
            '3-1': { electron: 'Tetrahedral', molecular: 'Trigonal Pyramidal', angle: 107 },
            '2-2': { electron: 'Tetrahedral', molecular: 'Bent', angle: 104.5 },
            '5-0': { electron: 'Trigonal Bipyramidal', molecular: 'Trigonal Bipyramidal', angle: 90 },
            '4-1': { electron: 'Trigonal Bipyramidal', molecular: 'Seesaw', angle: 117 },
            '3-2': { electron: 'Trigonal Bipyramidal', molecular: 'T-shaped', angle: 87 },
            '2-3': { electron: 'Trigonal Bipyramidal', molecular: 'Linear', angle: 180 },
            '6-0': { electron: 'Octahedral', molecular: 'Octahedral', angle: 90 },
            '5-1': { electron: 'Octahedral', molecular: 'Square Pyramidal', angle: 88 },
            '4-2': { electron: 'Octahedral', molecular: 'Square Planar', angle: 90 },
        };
        this.electronegativityData = {
            'H': 2.20, 'Be': 1.57, 'B': 2.04, 'C': 2.55, 'N': 3.04, 'O': 3.44, 'F': 3.98,
            'S': 2.58, 'Cl': 3.16, 'Xe': 2.60
        };
    }

    calculateGeometry(molecule, engine) {
        if (!molecule || !molecule.atomIds || molecule.atomIds.length < 2) return null;
        const atoms = molecule.atomIds.map(id => engine.atoms.find(a => a.id === id)).filter(a => a);
        if (atoms.length < 2) return null;
        const centralAtom = this.findCentralAtom(atoms, engine);
        if (!centralAtom) return null;
        const bondingPairs = this.countBondingPairs(centralAtom, engine);
        const lonePairs = centralAtom.lonePairs || 0;
        const geometryKey = `${bondingPairs}-${lonePairs}`;
        const geometry = this.geometryTable[geometryKey];
        return {
            centralAtom: centralAtom.element.symbol,
            bondingPairs,
            lonePairs,
            electronGeometry: geometry ? geometry.electron : 'Unknown',
            molecularGeometry: geometry ? geometry.molecular : 'Unknown',
            bondAngle: geometry ? geometry.angle : null,
        };
    }

    findCentralAtom(atoms, engine) {
        if (atoms.length === 2) {
            const en1 = this.getElectronegativity(atoms[0]);
            const en2 = this.getElectronegativity(atoms[1]);
            return en1 <= en2 ? atoms[0] : atoms[1];
        }
        let maxBonds = 0;
        let centralAtom = atoms[0];
        atoms.forEach(atom => {
            const bondCount = engine.bonds.filter(bond =>
                bond.a1.id === atom.id || bond.a2.id === atom.id
            ).length;
            if (bondCount > maxBonds) {
                maxBonds = bondCount;
                centralAtom = atom;
            }
        });
        return centralAtom;
    }

    countBondingPairs(atom, engine) {
        return engine.bonds.filter(bond =>
            bond.a1.id === atom.id || bond.a2.id === atom.id
        ).length;
    }

    getElectronegativity(atom) {
        return atom.element.electronegativity_pauling || this.electronegativityData[atom.element.symbol] || 2.0;
    }
}

// Helper to create test molecules
function makeAtom(id, symbol, lonePairs = 0) {
    return {
        id,
        element: {
            symbol,
            electronegativity_pauling: {
                'H': 2.20, 'Be': 1.57, 'B': 2.04, 'C': 2.55, 'N': 3.04,
                'O': 3.44, 'F': 3.98, 'S': 2.58, 'Cl': 3.16, 'Xe': 2.60
            }[symbol] || 2.0
        },
        lonePairs
    };
}

function makeBond(a1, a2) {
    return { a1, a2, id: `${a1.id}-${a2.id}`, type: 'single', order: 1, isIonic: false };
}

// Test cases: molecule, expected electron geometry, expected molecular geometry
const tests = [];
const calc = new VSEPRCalculator();

// H2O: O central, 2 bonding, 2 lone pairs → Tetrahedral / Bent
{
    const O = makeAtom('o1', 'O', 2);
    const H1 = makeAtom('h1', 'H', 0);
    const H2 = makeAtom('h2', 'H', 0);
    const engine = {
        atoms: [O, H1, H2],
        bonds: [makeBond(O, H1), makeBond(O, H2)]
    };
    const mol = { atomIds: ['o1', 'h1', 'h2'] };
    tests.push({ name: 'H2O', engine, mol, expectElectron: 'Tetrahedral', expectMolecular: 'Bent' });
}

// CO2: C central, 2 bonding, 0 lone pairs → Linear / Linear
{
    const C = makeAtom('c1', 'C', 0);
    const O1 = makeAtom('o1', 'O', 2);
    const O2 = makeAtom('o2', 'O', 2);
    const engine = {
        atoms: [C, O1, O2],
        bonds: [makeBond(C, O1), makeBond(C, O2)]
    };
    const mol = { atomIds: ['c1', 'o1', 'o2'] };
    tests.push({ name: 'CO2', engine, mol, expectElectron: 'Linear', expectMolecular: 'Linear' });
}

// NH3: N central, 3 bonding, 1 lone pair → Tetrahedral / Trigonal Pyramidal
{
    const N = makeAtom('n1', 'N', 1);
    const H1 = makeAtom('h1', 'H', 0);
    const H2 = makeAtom('h2', 'H', 0);
    const H3 = makeAtom('h3', 'H', 0);
    const engine = {
        atoms: [N, H1, H2, H3],
        bonds: [makeBond(N, H1), makeBond(N, H2), makeBond(N, H3)]
    };
    const mol = { atomIds: ['n1', 'h1', 'h2', 'h3'] };
    tests.push({ name: 'NH3', engine, mol, expectElectron: 'Tetrahedral', expectMolecular: 'Trigonal Pyramidal' });
}

// CH4: C central, 4 bonding, 0 lone pairs → Tetrahedral / Tetrahedral
{
    const C = makeAtom('c1', 'C', 0);
    const H1 = makeAtom('h1', 'H', 0);
    const H2 = makeAtom('h2', 'H', 0);
    const H3 = makeAtom('h3', 'H', 0);
    const H4 = makeAtom('h4', 'H', 0);
    const engine = {
        atoms: [C, H1, H2, H3, H4],
        bonds: [makeBond(C, H1), makeBond(C, H2), makeBond(C, H3), makeBond(C, H4)]
    };
    const mol = { atomIds: ['c1', 'h1', 'h2', 'h3', 'h4'] };
    tests.push({ name: 'CH4', engine, mol, expectElectron: 'Tetrahedral', expectMolecular: 'Tetrahedral' });
}

// H2S: S central, 2 bonding, 2 lone pairs → Tetrahedral / Bent
{
    const S = makeAtom('s1', 'S', 2);
    const H1 = makeAtom('h1', 'H', 0);
    const H2 = makeAtom('h2', 'H', 0);
    const engine = {
        atoms: [S, H1, H2],
        bonds: [makeBond(S, H1), makeBond(S, H2)]
    };
    const mol = { atomIds: ['s1', 'h1', 'h2'] };
    tests.push({ name: 'H2S', engine, mol, expectElectron: 'Tetrahedral', expectMolecular: 'Bent' });
}

// BF3: B central, 3 bonding, 0 lone pairs → Trigonal Planar / Trigonal Planar
{
    const B = makeAtom('b1', 'B', 0);
    const F1 = makeAtom('f1', 'F', 3);
    const F2 = makeAtom('f2', 'F', 3);
    const F3 = makeAtom('f3', 'F', 3);
    const engine = {
        atoms: [B, F1, F2, F3],
        bonds: [makeBond(B, F1), makeBond(B, F2), makeBond(B, F3)]
    };
    const mol = { atomIds: ['b1', 'f1', 'f2', 'f3'] };
    tests.push({ name: 'BF3', engine, mol, expectElectron: 'Trigonal Planar', expectMolecular: 'Trigonal Planar' });
}

// SF6: S central, 6 bonding, 0 lone pairs → Octahedral / Octahedral
{
    const S = makeAtom('s1', 'S', 0);
    const F1 = makeAtom('f1', 'F', 3);
    const F2 = makeAtom('f2', 'F', 3);
    const F3 = makeAtom('f3', 'F', 3);
    const F4 = makeAtom('f4', 'F', 3);
    const F5 = makeAtom('f5', 'F', 3);
    const F6 = makeAtom('f6', 'F', 3);
    const engine = {
        atoms: [S, F1, F2, F3, F4, F5, F6],
        bonds: [makeBond(S, F1), makeBond(S, F2), makeBond(S, F3), makeBond(S, F4), makeBond(S, F5), makeBond(S, F6)]
    };
    const mol = { atomIds: ['s1', 'f1', 'f2', 'f3', 'f4', 'f5', 'f6'] };
    tests.push({ name: 'SF6', engine, mol, expectElectron: 'Octahedral', expectMolecular: 'Octahedral' });
}

// Run tests
let passed = 0;
let failed = 0;

tests.forEach(test => {
    const result = calc.calculateGeometry(test.mol, test.engine);
    const eOk = result && result.electronGeometry === test.expectElectron;
    const mOk = result && result.molecularGeometry === test.expectMolecular;

    if (eOk && mOk) {
        console.log(`✓ ${test.name}: ${result.electronGeometry} / ${result.molecularGeometry} (central: ${result.centralAtom}, BP: ${result.bondingPairs}, LP: ${result.lonePairs})`);
        passed++;
    } else {
        console.log(`✗ ${test.name}: got ${result?.electronGeometry || 'null'}/${result?.molecularGeometry || 'null'}, expected ${test.expectElectron}/${test.expectMolecular}`);
        if (result) console.log(`  → central: ${result.centralAtom}, BP: ${result.bondingPairs}, LP: ${result.lonePairs}`);
        failed++;
    }
});

console.log(`\n${passed}/${passed + failed} tests passed`);
process.exit(failed > 0 ? 1 : 0);
