# Atomency - Molecular Modeling Platform

## Overview
Educational chemistry platform for K-12 instruction featuring:
- Interactive Periodic Table (118 elements)
- Molecular Builder with automatic bonding
- VSEPR Geometry Visualization
- Reaction Kinetics Simulator
- Nuclear Decay Simulator

## Usage
Open index.html in your browser.

## NGSS Standards
HS-PS1-1, HS-PS1-2, HS-PS1-5, HS-PS1-6, HS-PS1-8

## Credits
Built by Ky'lin Spears | © 2026
