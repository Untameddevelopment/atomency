/**
 * Verify mobile responsive fix for /lab route
 * Checks that root index.html includes mobile CSS, JS, and init code
 */
const fs = require('fs');
const path = require('path');

let passed = 0;
let failed = 0;

function check(name, condition) {
  if (condition) {
    console.log(`✅ ${name}`);
    passed++;
  } else {
    console.log(`❌ ${name}`);
    failed++;
  }
}

// Read root index.html (the file served at /lab)
const rootHtml = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');

// 1. Mobile CSS is linked
check('Root index.html links mobile-responsive.css',
  rootHtml.includes('mobile-responsive.css'));

// 2. Mobile JS is linked
check('Root index.html links mobile-enhancements.js',
  rootHtml.includes('mobile-enhancements.js'));

// 3. initMobileUI function exists
check('Root index.html has initMobileUI function',
  rootHtml.includes('function initMobileUI'));

// 4. showPageMobile function exists
check('Root index.html has showPageMobile function',
  rootHtml.includes('function showPageMobile'));

// 5. closeBottomSheet function exists
check('Root index.html has closeBottomSheet function',
  rootHtml.includes('function closeBottomSheet'));

// 6. initMobileUI is called on load
check('initMobileUI() is called on window load',
  rootHtml.includes('initMobileUI()'));

// 7. Mobile nav HTML is generated with correct tabs
check('Mobile nav includes Lab tab',
  rootHtml.includes("showPageMobile('simulator')"));
check('Mobile nav includes Table tab',
  rootHtml.includes("showPageMobile('home')"));
check('Mobile nav includes Reactions tab',
  rootHtml.includes("showPageMobile('reactions')"));
check('Mobile nav includes Nuclear/Decay tab',
  rootHtml.includes("showPageMobile('nuclear')"));

// 8. CSS file exists and hides sidebar
const mobileCss = fs.readFileSync(path.join(__dirname, 'public/css/mobile-responsive.css'), 'utf8');
check('Mobile CSS hides #left-sidebar',
  mobileCss.includes('#left-sidebar') && mobileCss.includes('display: none !important'));
check('Mobile CSS removes ml-16 margin',
  mobileCss.includes('margin-left: 0 !important'));
check('Mobile CSS has .mobile-nav styles',
  mobileCss.includes('.mobile-nav'));

// 9. Mobile enhancements JS exists
check('mobile-enhancements.js exists',
  fs.existsSync(path.join(__dirname, 'public/js/mobile-enhancements.js')));

// 10. Server serves root index.html for /lab
const serverJs = fs.readFileSync(path.join(__dirname, 'server.js'), 'utf8');
check('Server serves index.html for /lab route',
  serverJs.includes("app.get('/lab'") && serverJs.includes("'index.html'"));

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
