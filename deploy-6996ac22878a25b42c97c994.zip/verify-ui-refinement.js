const fs = require('fs');

console.log('🔍 VERIFICATION: Lab UI Refinement\n');

// Check 1: Particle visibility increased
const cssContent = fs.readFileSync('css/alchemist-style.css', 'utf8');
const htmlContent = fs.readFileSync('index.html', 'utf8');

const particleDotOpacity = htmlContent.match(/rgba\(255,255,255,([\d.]+)\).*background-size: 40px 40px/);
if (particleDotOpacity && parseFloat(particleDotOpacity[1]) >= 0.25) {
    console.log('✅ Particle dots visibility: INCREASED (opacity 0.25)');
} else {
    console.log('❌ Particle dots visibility: NOT INCREASED');
}

// Check 2: Gold accent color defined
if (htmlContent.includes('accent: "#d47f0f"')) {
    console.log('✅ Gold accent color defined: #d47f0f');
} else {
    console.log('❌ Gold accent color not defined');
}

// Check 3: Panel shadows enhanced
if (cssContent.includes('box-shadow: 0 20px 60px') && cssContent.includes('rgba(212, 127, 15')) {
    console.log('✅ Panel shadows enhanced with gold glows');
} else {
    console.log('❌ Panel shadows not enhanced');
}

// Check 4: Active button states updated to gold
if (cssContent.includes('border-color: #d47f0f')) {
    console.log('✅ Active button states use gold accent');
} else {
    console.log('❌ Active button states not updated');
}

// Check 5: Hover state transitions
if (cssContent.includes('transition: all 0.2s ease')) {
    console.log('✅ Smooth hover state transitions added');
} else {
    console.log('❌ Hover state transitions missing');
}

// Check 6: All scientific functionality preserved
const jsFiles = [
    'js/alchemist-engine.js',
    'js/vsepr-geometry.js',
    'js/vsepr-physics.js',
    'js/vsepr-visual.js',
    'js/reaction-kinetics.js',
    'js/nuclear-decay.js'
];

let allEnginesPresent = true;
jsFiles.forEach(file => {
    if (!fs.existsSync(file)) {
        console.log(`❌ Missing: ${file}`);
        allEnginesPresent = false;
    }
});

if (allEnginesPresent) {
    console.log('✅ All scientific engines intact');
} else {
    console.log('❌ Some engines missing');
}

// Check 7: Download/Export button preserved
if (htmlContent.includes('btn-export') && htmlContent.includes('exportMolecule')) {
    console.log('✅ Export/Download functionality preserved');
} else {
    console.log('❌ Export functionality missing');
}

console.log('\n✨ UI Refinement verification complete!');
