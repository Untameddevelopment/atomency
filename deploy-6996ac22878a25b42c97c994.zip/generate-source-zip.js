/**
 * ATOMENCY - SOURCE CODE ZIP GENERATOR
 * Dynamically generates atomency-source.zip from all source files
 * Runs automatically on every deploy via build script
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('📦 Generating atomency-source.zip from current source...\n');

// Ensure output directory exists
const outputDir = 'public/downloads';
const legacyDir = 'public/download';
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}
if (!fs.existsSync(legacyDir)) {
  fs.mkdirSync(legacyDir, { recursive: true });
}

try {
  // Use git ls-files to get all tracked files (excludes .git, node_modules automatically)
  // This ensures the zip always contains what's in the current commit
  let filesToZip;
  try {
    filesToZip = execSync('git ls-files', { encoding: 'utf-8' })
      .trim()
      .split('\n')
      .filter(file => {
        // Exclude internal, sensitive, build, and temporary files
        const excludePatterns = [
          /^node_modules/,           // Dependencies
          /^\.git/,                  // Git files
          /^\.env/,                  // Environment variables
          /\.log$/,                  // Log files
          /^public\/downloads/,      // Download directory
          /^public\/download/,       // Legacy download directory
          /-source\.zip$/,           // Zip files
          /^\.claude/,               // Claude internal config
          /^debug\//,                // Debug logs
          /^projects\//,             // Project tracking
          /^analytics\//,            // Analytics data
          /\.backup\./,              // Backup files
          /^test-/,                  // Test files
          /^tmp\//,                  // Temp files
        ];

        return !excludePatterns.some(pattern => pattern.test(file)) && fs.existsSync(file);
      });
  } catch (gitError) {
    // Fallback if git not available: use find command
    console.log('⚠️  Git not available, using fallback file discovery...');
    filesToZip = execSync('find . -type f', { encoding: 'utf-8' })
      .trim()
      .split('\n')
      .map(f => f.replace(/^\.\//, ''))
      .filter(file => {
        const excludePatterns = [
          /^node_modules/, /^\.git/, /^\.env/, /\.log$/, /^public\/downloads/,
          /^public\/download/, /^\.claude/, /^debug\//, /^projects\//, /^analytics\//
        ];
        return !excludePatterns.some(pattern => pattern.test(file)) && fs.existsSync(file);
      });
  }

  if (filesToZip.length === 0) {
    console.error('❌ ERROR: No source files found to include in zip');
    process.exit(1);
  }

  console.log(`📂 Found ${filesToZip.length} source files\n`);

  // Create zip with all source files
  const zipPath = path.join(outputDir, 'atomency-source.zip');
  const legacyZipPath = path.join(legacyDir, 'atomency-source.zip');

  // Remove old zips
  [zipPath, legacyZipPath].forEach(p => {
    if (fs.existsSync(p)) fs.unlinkSync(p);
  });

  // Create new zip (quieter output for build logs)
  execSync(`zip -q -r ${zipPath} ${filesToZip.join(' ')} -x "*.DS_Store"`, { stdio: 'inherit' });

  // Copy to legacy path for backward compatibility
  fs.copyFileSync(zipPath, legacyZipPath);

  // Also copy as chemsuite-source.zip for legacy URLs
  fs.copyFileSync(zipPath, path.join(outputDir, 'chemsuite-source.zip'));
  fs.copyFileSync(zipPath, path.join(legacyDir, 'chemsuite-source.zip'));

  // Get file size
  const stats = fs.statSync(zipPath);
  const sizeKB = (stats.size / 1024).toFixed(2);

  console.log(`\n✅ ZIP GENERATED SUCCESSFULLY`);
  console.log(`📁 File: atomency-source.zip`);
  console.log(`📊 Size: ${sizeKB} KB`);
  console.log(`📂 Files included: ${filesToZip.length}`);
  console.log(`📅 Created: ${new Date(stats.mtime).toLocaleString()}`);
  console.log(`\n✨ Available at:`);
  console.log(`   - /downloads/atomency-source.zip`);
  console.log(`   - /download/atomency-source.zip (legacy)`);
  console.log(`   - /downloads/chemsuite-source.zip (legacy)\n`);

} catch (error) {
  console.error('❌ ERROR generating zip:', error.message);
  process.exit(1);
}
