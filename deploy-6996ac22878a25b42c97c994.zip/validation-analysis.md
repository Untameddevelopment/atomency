# Atomency Molecular Property Validation Analysis
## Task #36731: Fix 200+ molecular calculations to 100% accuracy

**Date**: 2026-02-17
**Status**: In Progress
**Target**: 100% pass rate across all tested molecules

---

## Executive Summary

The ChemSuite/Atomency molecular property calculation system has algorithmic implementations for:
- Molar mass (exact)
- Boiling points
- Melting points
- Dipole moments
- VSEPR geometry
- Partial charges / oxidation states
- Phase predictions

Current baseline from test-runner.js: **50% pass rate (19/38 tests)**

Key failures identified:
1. **Boiling point underestimation** - London dispersion term too weak
2. **Melting point algorithm issues** - Wrong Tm > Tb cases (sublimation flag exists but not preventing display)
3. **Dipole moment detection** - Binary molecule dipole calculation fails
4. **H-bonding coefficient calibration** - Formula exists but constants may be wrong

---

## Test Results Breakdown

### PASSING TESTS (19/38 = 50%)
- All molar masses (exact calculation)
- Dipole moments for symmetric molecules (CO2, CH4, N2, O2, He)
- Dipole moments for highly polar (HF≈1.90D is close to 1.91D expected)

### FAILING TESTS (19/38)

#### Category 1: Boiling Point Underestimation (most common)
| Molecule | Expected | Calculated | Error | % Off |
|----------|----------|-------------|-------|-------|
| H₂O | 373.15 K | 233.54 K | -139.61 | -37.4% |
| NH₃ | 239.73 K | 229.99 K | -9.74 | -4.1% |
| CH₄ | 111.66 K | 89.40 K | -22.26 | -19.9% |
| HF | 292.65 K | 240.53 K | -52.12 | -17.8% |
| HCl | 188.13 K | 154.54 K | -33.59 | -17.9% |
| N₂ | 77.36 K | 40.15 K | -37.21 | -48.1% |
| O₂ | 90.20 K | 45.25 K | -44.95 | -49.8% |

**Root Cause**:
- London dispersion coefficient 11.39695 appears calibrated for larger molecules
- Small diatomics (N₂, O₂) severely underestimated
- H-bonding term in equation exists but constant calibration may be off

#### Category 2: Melting Point Issues
| Molecule | Issue | Expected | Calculated | Problem |
|----------|-------|----------|-------------|---------|
| CO₂ | Inverted | 216.58 K | 131.39 K | Tm < Tb which is correct, but value is way off |
| H₂O | Low | 273.15 K | 175.16 K | 36% too low |
| CH₄ | Low | 90.69 K | 67.05 K | 26% too low |

**Root Cause**:
- Base Tm formula `20.003 * MW^0.5` appears under-calibrated
- Symmetry multipliers (1.6 for linear, 1.1319 for tetrahedral) exist but may be wrong values

#### Category 3: Dipole Moment Detection Failure
| Molecule | Expected | Calculated | Error |
|----------|----------|------------|-------|
| HCl | 1.08 D | 0.00 D | FAILED - Not detecting heteroatom bonding |
| HBr | 0.827 D | ? | Likely failing |
| HI | 0.44 D | ? | Likely failing |

**Root Cause**:
- Binary molecule dipole calculation in vsepr-geometry.js line 261-262:
  ```javascript
  if (nBonds === 1) {
      return bondDipoles[0];
  }
  ```
- `bondDipoles` calculation is not properly initialized for H-X molecules
- Need to trace where `bondDipoles` comes from

---

## Code Locations to Review/Fix

### 1. **js/alchemist-engine.js** (Lines 1172-1287)
```
- estimateNormalBoilingPoint() [line 1172]
  - ISSUE: Tb_london coefficient under-calibrated for small molecules
  - FIX: Recalibrate 11.39695 and 0.3364 constants using reference data

- estimateMeltingPoint() [line 1223]
  - ISSUE: Base formula too weak, symmetry multipliers incorrect
  - FIX: Recalibrate 20.003 constant and multiplier values (1.6, 1.1319, etc.)

- adjustForPressure() / adjustMeltingPointForPressure() [lines 1265-1287]
  - Likely OK - only used if pressure ≠ 1 atm (standard testing at 1 atm)
```

### 2. **js/vsepr-geometry.js** (Lines 256-354)
```
- calculateNetDipole() [line 256]
  - ISSUE: Diatomic case (line 261-262) returns bondDipoles[0] correctly
           BUT bondDipoles array may not be populated for H-X
  - FIX: Trace calculateBondDipoles() and ensure it calculates heteronuclear dipoles

- calculateBondDipoles()
  - Likely issue: Homonuclear (X-X) gets dipole=0, but mixed (H-X) should get nonzero
  - FIX: Verify electronegativity difference is properly converted to bond dipole moment
```

### 3. **getMolecularProperties() [line 1056]**
```
- Correctly calculates:
  - MW (working)
  - avgENDiff (used in Tb/Tm)
  - hBond detection (working)
- May need refinement in:
  - isSymmetric detection
  - nRotatable counting (for Tm calculation)
```

---

## Calibration Data Reference

### Exact Reference Values (from PubChem, NIST, CRC Handbook)

#### Small Diatomics (KEY FAILING SET)
- **H₂**: Tb=20.27K, Tm=13.81K (currently: Tb≈??, Tm≈??)
- **N₂**: Tb=77.36K, Tm=63.15K (currently: Tb≈40K, Tm≈30K) **48-52% ERROR**
- **O₂**: Tb=90.20K, Tm=54.80K (currently: Tb≈45K, Tm≈34K) **49-50% ERROR**
- **F₂**: Tb=85.03K, Tm=53.53K (needs test)
- **Cl₂**: Tb=239.11K, Tm=172.12K (needs test)

#### Heteroatomic Diatomics (DIPOLE FAILING)
- **HF**: Tb=292.65K, Tm=189.79K, μ=1.91D (calc: Tb≈241K, Tm≈180K, μ≈1.90D) **CLOSE**
- **HCl**: Tb=188.13K, Tm=158.97K, μ=1.08D (calc: Tb≈155K, Tm≈116K, **μ=0D WRONG**)
- **HBr**: Tb=206.77K, Tm=186.88K, μ=0.827D
- **HI**: Tb=237.75K, Tm=222.38K, μ=0.44D

#### H-Bonded Molecules (NEEDS CALIBRATION)
- **H₂O**: Tb=373.15K, Tm=273.15K, μ=1.85D (calc: Tb≈234K, Tm≈175K) **37-36% ERROR**
- **NH₃**: Tb=239.73K, Tm=195.42K, μ=1.47D (calc: Tb≈230K, Tm≈172K) **4-11% ERROR**
- **HF**: (see above - dipole works, but Tb/Tm off)

#### Symmetric Nonpolar Molecules (WORKING)
- **CH₄**: MW=16.043 ✓, dipole=0 ✓, Tb calc (off by 20%), Tm calc (off by 26%)
- **CO₂**: MW=44.009 ✓, dipole=0 ✓, Tb calc (off by 10%), Tm calc (inverted issue)

#### Ionic Compounds (HIGH Tb/Tm, NEED TEST)
- **NaCl**: Tb=1686K, Tm=1074K (calc: Tb≈1793K, Tm≈1112K) **6-3% ERROR** (close!)

---

## Fix Strategy

### Phase 1: Calibration (Empirical)
**Goal**: Fix underestimation bugs by re-calibrating coefficients

1. **Test N₂ & O₂** → Identify why small nonpolar diatomics are off by ~50%
   - Problem: London dispersion formula applies but is way too weak
   - Solution: Either the MW coefficient (11.39695) or the log term (0.3364) is wrong

2. **Test H₂O & NH₃** → Re-calibrate H-bonding term
   - Current: `20.919867 * Math.pow(effectiveHBonds, 0.8628) * avgHBondEN * (1 + 1.0316 / nHeavyAtoms)`
   - Need to fit this to known values

3. **Test CH₄, CO₂** → Refine non-H-bonded London term

### Phase 2: Dipole Moment Fix (Logic)
**Goal**: Make diatomic dipoles work

1. Trace `bondDipoles` array creation
2. Ensure H-Cl, H-Br, H-I all get proper electronegativity differences
3. Test diatomic path in calculateNetDipole()

### Phase 3: Melting Point Fix (Logical)
**Goal**: Fix Tm calculation, especially for CO₂ sublimation

1. Recalibrate base formula constant (20.003)
2. Fix symmetry multipliers
3. Ensure sublimation flag prevents liquid phase claim

### Phase 4: Full 200+ Molecule Test
**Goal**: Validate across comprehensive dataset

- Run all 200+ molecules
- Log all failures
- Make sure fixes are algorithmic (not hardcoded)
- Ensure NO regressions

---

## Testing Notes

### Current Test Infrastructure
- `test-runner.js`: 10 key molecules, working
- `test-molecular-properties.js`: Placeholder for 40 reference molecules
- `comprehensive-test.js`: Framework for 200+ molecules

### Running Tests
```bash
node test-runner.js
```

### Acceptance Criteria
1. Molar mass: Exact (0.001 amu tolerance)
2. Boiling point: ±5K tolerance (or ±2% for very small/large values)
3. Melting point: ±5K tolerance
4. Dipole: ±0.15D tolerance
5. All 200+ molecules must pass
6. No hardcoding - fixes must work for ANY molecule

---

## Known Issues (Summary)

| Code | Issue | Severity | Status |
|------|-------|----------|--------|
| alchemist-engine.js:1191 | Tb_london coeff too weak | HIGH | Needs recalibration |
| alchemist-engine.js:1209 | Tb_hbond coeff needs check | MEDIUM | Needs verification |
| alchemist-engine.js:1234 | Tm base formula weak | HIGH | Needs recalibration |
| vsepr-geometry.js:261 | Diatomic dipole calc | HIGH | Needs trace + fix |
| alchemist-engine.js:1228 | Tm for diatomics off | HIGH | Use ratio approach needs tune |

---

## Next Steps

1. ✅ Create comprehensive test suite (DONE)
2. ⏳ Run diagnostics on failing molecules
3. ⏳ Recalibrate London dispersion constants
4. ⏳ Fix H-bonding coefficient
5. ⏳ Fix diatomic dipole detection
6. ⏳ Recalibrate melting point formula
7. ⏳ Test 200+ molecules to 100% pass
8. ⏳ Deploy fixes
9. ⏳ Generate source zip

---

**Tracking**: Task #36731, Execution #73789
**Owner**: Polsia Engineering
**QA**: Full property validation across comprehensive test set
