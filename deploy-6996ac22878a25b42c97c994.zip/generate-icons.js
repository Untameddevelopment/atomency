const fs = require('fs');
const path = require('path');

const createSVGIcon = (size) => {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}">
  <defs>
    <linearGradient id="iconGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#6366f1;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#4338ca;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="${size}" height="${size}" rx="${size * 0.15}" fill="url(#iconGradient)"/>
  <text x="50%" y="${size * 0.72}" font-size="${size * 0.6}" font-weight="900" font-style="italic" text-anchor="middle" fill="white" font-family="system-ui, -apple-system, sans-serif">C</text>
</svg>`;
};

const iconsDir = path.join(__dirname, 'public', 'icons');
fs.mkdirSync(iconsDir, { recursive: true });

fs.writeFileSync(path.join(iconsDir, 'icon-192x192.svg'), createSVGIcon(192));
fs.writeFileSync(path.join(iconsDir, 'icon-512x512.svg'), createSVGIcon(512));

console.log('✓ Generated PWA icons (192x192 and 512x512)');
