const fetch = require('node-fetch');
const FormData = require('form-data');
const fs = require('fs');

// Load .env file manually
const envContent = fs.readFileSync('.env', 'utf8');
const envVars = {};
envContent.split('\n').forEach(line => {
  const match = line.match(/^([^=]+)=(.*)$/);
  if (match) {
    envVars[match[1]] = match[2];
  }
});

async function uploadZip() {
  const fileBuffer = fs.readFileSync('atomency-source.zip');
  const formData = new FormData();

  formData.append('file', fileBuffer, {
    filename: 'atomency-source.zip',
    contentType: 'application/zip'
  });

  const response = await fetch('https://polsia.com/api/proxy/r2/upload', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${envVars.POLSIA_API_KEY}`,
      ...formData.getHeaders()
    },
    body: formData
  });

  const result = await response.json();

  if (!result.success) {
    console.error('Upload failed:', result.error);
    process.exit(1);
  }

  console.log('SUCCESS!');
  console.log('Download URL:', result.file.url);
  console.log('File size:', (result.file.size / (1024 * 1024)).toFixed(2), 'MB');
}

uploadZip().catch(err => {
  console.error('Error:', err);
  process.exit(1);
});
