/**
 * Verify that collision physics fix prevents explosive atom displacement.
 * Simulates 6 large atoms placed at the same position and checks that
 * after resolve(), no atom moves more than a reasonable distance.
 */

// Mock the engine minimally
const fs = require('fs');
const vm = require('vm');

// Load engine
const engineCode = fs.readFileSync('./js/alchemist-engine.js', 'utf8');
const sandbox = { window: {}, console, Math, fetch: () => Promise.reject(), Map, Set, Infinity, Array, Object, parseInt, parseFloat, Promise, RegExp };
vm.createContext(sandbox);
vm.runInContext(engineCode, sandbox);

const ChemistryEngine = sandbox.window.ChemistryEngine;
const engine = new ChemistryEngine();

// Mock elements data — simulate 6 large transition metal atoms (radius ~45px each)
const mockElement = {
    symbol: 'Fe', name: 'Iron', number: 26, period: 4, group: 8,
    atomic_mass: 55.845, category: 'transition metal',
    electronegativity_pauling: 1.83, shells: [2, 8, 14, 2]
};

engine.elements = [mockElement];

// Place 6 atoms AT THE SAME POSITION (worst case)
const cx = 400, cy = 300;
for (let i = 0; i < 6; i++) {
    engine.atoms.push({
        id: `atom-${i}`,
        element: mockElement,
        x: cx + (Math.random() - 0.5) * 2, // Near-zero spread
        y: cy + (Math.random() - 0.5) * 2,
        charge: 0,
        oxidationState: 0
    });
}

console.log('Initial positions:');
engine.atoms.forEach(a => console.log(`  ${a.id}: (${a.x.toFixed(1)}, ${a.y.toFixed(1)})`));

// Run resolve (which calls applyCollisionPhysics)
engine.resolve();

console.log('\nAfter resolve():');
let maxDisplacement = 0;
engine.atoms.forEach(a => {
    const dx = a.x - cx;
    const dy = a.y - cy;
    const dist = Math.sqrt(dx * dx + dy * dy);
    maxDisplacement = Math.max(maxDisplacement, dist);
    console.log(`  ${a.id}: (${a.x.toFixed(1)}, ${a.y.toFixed(1)}) — displacement: ${dist.toFixed(1)}px`);
});

console.log(`\nMax displacement from center: ${maxDisplacement.toFixed(1)}px`);

// PASS: max displacement should be < 100px (old code would produce 300+)
if (maxDisplacement < 100) {
    console.log('✅ PASS — atoms settled gently, no explosive displacement');
    process.exit(0);
} else {
    console.log(`❌ FAIL — max displacement ${maxDisplacement.toFixed(1)}px exceeds 100px threshold`);
    process.exit(1);
}
