const express = require('express');
const { Pool } = require('pg');
const path = require('path');
const fs = require('fs');

const app = express();
const port = process.env.PORT || 3000;

// Fail fast if DATABASE_URL is missing
if (!process.env.DATABASE_URL) {
  console.error('ERROR: DATABASE_URL environment variable is required');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false }
});

// Bot detection patterns
const BOT_PATTERNS = [
  /bot/i, /crawler/i, /spider/i, /crawling/i,
  /facebookexternalhit/i, /twitterbot/i, /whatsapp/i,
  /linkedinbot/i, /slackbot/i, /googlebot/i, /bingbot/i,
  /yandex/i, /baiduspider/i, /duckduckbot/i,
  /gptbot/i, /claudebot/i, /anthropic-ai/i, /openai/i,
  /screenshot/i, /preview/i,
  /python-requests/i, /axios/i, /postman/i, /insomnia/i,
  /lighthouse/i, /pagespeed/i, /gtmetrix/i, /pingdom/i,
  /uptimerobot/i, /headless/i, /phantom/i, /selenium/i, /webdriver/i
];

function isBot(userAgent) {
  if (!userAgent || userAgent.trim() === '') return true;
  return BOT_PATTERNS.some(pattern => pattern.test(userAgent));
}

// Analytics tracking helper
async function trackEvent(eventType, visitorId, pagePath, metadata = {}) {
  try {
    const userAgent = metadata.user_agent || null;
    const ipAddress = metadata.ip_address || null;
    const referrer = metadata.referrer || null;

    // Console logging for Render
    console.log(JSON.stringify({
      event: 'analytics_event',
      timestamp: new Date().toISOString(),
      event_type: eventType,
      page_path: pagePath,
      visitor_id: visitorId,
      metadata
    }));

    await pool.query(`
      INSERT INTO analytics_events (event_type, event_data, visitor_id, user_agent, ip_address, referrer, page_path)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
    `, [eventType, JSON.stringify(metadata), visitorId, userAgent, ipAddress, referrer, pagePath]);
  } catch (err) {
    console.error('[analytics] Tracking error:', err.message);
  }
}

// Generate simple visitor ID from IP + User Agent
function generateVisitorId(req) {
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const ua = req.get('user-agent') || 'unknown';
  // Simple hash-like ID (not cryptographic, just for grouping)
  return Buffer.from(`${ip}-${ua}`).toString('base64').substring(0, 32);
}

app.use(express.json());

// Health check endpoint (required for Render)
// Note: Does NOT query database to allow Neon auto-suspend
app.get('/health', (req, res) => {
  res.json({ status: 'healthy' });
});

// Page view tracking middleware (MUST come BEFORE express.static)
app.use((req, res, next) => {
  const isPageView = !req.path.startsWith('/api') &&
                     !req.path.startsWith('/health') &&
                     !req.path.match(/\.(png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|css|js|json)$/i) &&
                     req.method === 'GET';

  if (isPageView) {
    const userAgent = req.get('user-agent');

    // Filter bot traffic
    if (!isBot(userAgent)) {
      const visitorId = generateVisitorId(req);
      const metadata = {
        user_agent: userAgent,
        ip_address: req.ip || req.connection.remoteAddress,
        referrer: req.get('referer') || req.get('referrer')
      };

      // Fire and forget - don't block the response
      trackEvent('page_view', visitorId, req.path, metadata)
        .catch(err => console.error('Page view tracking failed:', err.message));
    }
  }
  next();
});

// CRITICAL: Serve service-worker.js with no-cache so browsers always get the latest version
app.get('/service-worker.js', (req, res) => {
  res.set({
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0'
  });
  res.sendFile(path.join(__dirname, 'public', 'service-worker.js'));
});

// Serve static files from public folder (but NOT index.html - handled by custom route below)
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// Client-side analytics tracking endpoint
app.post('/api/track', async (req, res) => {
  const { event_type, event_data } = req.body;

  if (!event_type) {
    return res.status(400).json({ error: 'event_type required' });
  }

  // Validate event types (whitelist)
  const validEvents = [
    'page_view',
    'periodic_table_view',
    'molecule_built',
    'vsepr_calculated',
    'session_start',
    'session_end',
    'element_clicked',
    'molecule_searched',
    'molecule_3d_view',
    'export_clicked'
  ];

  if (!validEvents.includes(event_type)) {
    return res.status(400).json({ error: 'Invalid event type' });
  }

  try {
    const visitorId = generateVisitorId(req);
    const userAgent = req.get('user-agent');

    // Skip bot traffic
    if (isBot(userAgent)) {
      return res.json({ success: true, tracked: false });
    }

    const metadata = {
      user_agent: userAgent,
      ip_address: req.ip || req.connection.remoteAddress,
      referrer: req.get('referer') || req.get('referrer'),
      ...event_data
    };

    await trackEvent(event_type, visitorId, req.path, metadata);
    res.json({ success: true, tracked: true });
  } catch (err) {
    console.error('[analytics] Track error:', err);
    res.status(500).json({ error: 'Failed to track event' });
  }
});

// Analytics summary endpoint
app.get('/api/analytics/summary', async (req, res) => {
  try {
    const { days = 7 } = req.query;
    const daysAgo = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    // Total page views
    const pageViews = await pool.query(`
      SELECT COUNT(*) as count
      FROM analytics_events
      WHERE event_type = 'page_view' AND created_at > $1
    `, [daysAgo]);

    // Unique visitors
    const uniqueVisitors = await pool.query(`
      SELECT COUNT(DISTINCT visitor_id) as count
      FROM analytics_events
      WHERE event_type = 'page_view' AND created_at > $1 AND visitor_id IS NOT NULL
    `, [daysAgo]);

    // Top pages
    const topPages = await pool.query(`
      SELECT page_path, COUNT(*) as views
      FROM analytics_events
      WHERE event_type = 'page_view' AND created_at > $1
      GROUP BY page_path
      ORDER BY views DESC
      LIMIT 10
    `, [daysAgo]);

    // Event types breakdown
    const eventTypes = await pool.query(`
      SELECT event_type, COUNT(*) as count
      FROM analytics_events
      WHERE created_at > $1
      GROUP BY event_type
      ORDER BY count DESC
    `, [daysAgo]);

    // Feature usage
    const featureUsage = await pool.query(`
      SELECT
        SUM(CASE WHEN event_type = 'periodic_table_view' THEN 1 ELSE 0 END) as periodic_table,
        SUM(CASE WHEN event_type = 'molecule_built' THEN 1 ELSE 0 END) as molecule_builder,
        SUM(CASE WHEN event_type = 'vsepr_calculated' THEN 1 ELSE 0 END) as vsepr_calculator
      FROM analytics_events
      WHERE created_at > $1
    `, [daysAgo]);

    res.json({
      period: `Last ${days} days`,
      overview: {
        pageViews: parseInt(pageViews.rows[0].count),
        uniqueVisitors: parseInt(uniqueVisitors.rows[0].count)
      },
      popularPages: topPages.rows,
      eventTypes: eventTypes.rows,
      featureUsage: featureUsage.rows[0] || { periodic_table: 0, molecule_builder: 0, vsepr_calculator: 0 }
    });
  } catch (err) {
    console.error('[analytics] Summary error:', err);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

// Landing page (marketing/info page)
app.get('/', (req, res) => {
  const slug = process.env.POLSIA_ANALYTICS_SLUG || '';
  const htmlPath = path.join(__dirname, 'landing.html');

  if (fs.existsSync(htmlPath)) {
    let html = fs.readFileSync(htmlPath, 'utf8');
    // Inject the slug into the HTML
    html = html.replace('__POLSIA_SLUG__', slug);
    // Prevent browser from caching HTML (ensures users see latest About/Terms/Footer)
    res.set({
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });
    res.type('html').send(html);
  } else {
    res.json({ message: 'Landing page not found' });
  }
});

// Lab application route
app.get('/lab', (req, res) => {
  const slug = process.env.POLSIA_ANALYTICS_SLUG || '';
  const htmlPath = path.join(__dirname, 'index.html');

  if (fs.existsSync(htmlPath)) {
    let html = fs.readFileSync(htmlPath, 'utf8');
    // Inject the slug into the HTML
    html = html.replace('__POLSIA_SLUG__', slug);
    // Prevent browser from caching HTML (ensures users see latest About/Terms/Footer)
    res.set({
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });
    res.type('html').send(html);
  } else {
    res.json({ message: 'Lab application not found' });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
