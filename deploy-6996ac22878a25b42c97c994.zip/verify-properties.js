// Comprehensive verification script for molecular properties
// Tests the actual ChemistryEngine against known experimental values

const http = require('http');
const https = require('https');

// Reference data for test molecules
const TEST_MOLECULES = [
    { formula: 'H2O',    expBP: 373.15, expMP: 273.15, expDipole: 1.85, expMW: 18.015 },
    { formula: 'HCl',    expBP: 188.15, expMP: 158.97, expDipole: 1.08, expMW: 36.461 },
    { formula: 'CO2',    expBP: 194.65, expMP: 194.65, expDipole: 0,    expMW: 44.010 },
    { formula: 'NH3',    expBP: 239.82, expMP: 195.42, expDipole: 1.47, expMW: 17.031 },
    { formula: 'CH4',    expBP: 111.65, expMP: 90.70,  expDipole: 0,    expMW: 16.043 },
    { formula: 'NaCl',   expBP: 1686,   expMP: 1074,   expDipole: 9.0,  expMW: 58.443 },
    { formula: 'C2H5OH', expBP: 351.44, expMP: 159.05, expDipole: 1.69, expMW: 46.069 },
    { formula: 'C6H6',   expBP: 353.25, expMP: 278.65, expDipole: 0,    expMW: 78.114 },
    { formula: 'NaOH',   expBP: 1661,   expMP: 596,    expDipole: null, expMW: 39.997 },
    { formula: 'HBr',    expBP: 206.77, expMP: 186.35, expDipole: 0.82, expMW: 80.912 },
    { formula: 'HI',     expBP: 237.77, expMP: 222.37, expDipole: 0.44, expMW: 127.912 },
    { formula: 'O2',     expBP: 90.19,  expMP: 54.36,  expDipole: 0,    expMW: 31.998 },
    { formula: 'N2',     expBP: 77.36,  expMP: 63.15,  expDipole: 0,    expMW: 28.014 },
];

// Compute expected results for verification
console.log('=== MOLECULAR PROPERTY VERIFICATION ===');
console.log('Testing formulas against experimental data\n');

// BP tolerances
let bpPass = 0, bpFail = 0;
let mpPass = 0, mpFail = 0;

// We can't run the full engine in Node.js (it needs browser context),
// so we'll verify the formulas directly

// Element data (from Bowserinator API)
const ELEM = {
    H:  { mass: 1.008, en: 2.20, boil: 20.271, melt: 13.99, period: 1, group: 1, cat: 'diatomic nonmetal' },
    He: { mass: 4.003, en: 0, boil: 4.222, melt: 0.95, period: 1, group: 18, cat: 'noble gas' },
    C:  { mass: 12.011, en: 2.55, boil: 4098, melt: 3823, period: 2, group: 14, cat: 'polyatomic nonmetal' },
    N:  { mass: 14.007, en: 3.04, boil: 77.355, melt: 63.15, period: 2, group: 15, cat: 'diatomic nonmetal' },
    O:  { mass: 15.999, en: 3.44, boil: 90.188, melt: 54.36, period: 2, group: 16, cat: 'diatomic nonmetal' },
    F:  { mass: 18.998, en: 3.98, boil: 85.03, melt: 53.48, period: 2, group: 17, cat: 'diatomic nonmetal' },
    Na: { mass: 22.990, en: 0.93, boil: 1156.09, melt: 370.87, period: 3, group: 1, cat: 'alkali metal' },
    Cl: { mass: 35.453, en: 3.16, boil: 239.11, melt: 171.6, period: 3, group: 17, cat: 'diatomic nonmetal' },
    Br: { mass: 79.904, en: 2.96, boil: 332.0, melt: 265.8, period: 4, group: 17, cat: 'diatomic nonmetal' },
    I:  { mass: 126.904, en: 2.66, boil: 457.4, melt: 386.85, period: 5, group: 17, cat: 'diatomic nonmetal' },
    S:  { mass: 32.06, en: 2.58, boil: 717.8, melt: 388.36, period: 3, group: 16, cat: 'polyatomic nonmetal' },
};

const isDiatomicNonmetal = (el) => el.cat.includes('diatomic');
const isMetal = (el) => el.cat.includes('metal') && !el.cat.includes('nonmetal') && !el.cat.includes('metalloid');

function simulateEngine(formula) {
    const configs = {
        'H2O': { atoms: ['H','H','O'], centralAtom: 'O', lonePairs: 2, bonds: [['H','O',1],['H','O',1]], isIonic: false },
        'HCl': { atoms: ['H','Cl'], centralAtom: 'H', lonePairs: 0, bonds: [['H','Cl',1]], isIonic: false },
        'CO2': { atoms: ['C','O','O'], centralAtom: 'C', lonePairs: 0, bonds: [['C','O',2],['C','O',2]], isIonic: false },
        'NH3': { atoms: ['N','H','H','H'], centralAtom: 'N', lonePairs: 1, bonds: [['N','H',1],['N','H',1],['N','H',1]], isIonic: false },
        'CH4': { atoms: ['C','H','H','H','H'], centralAtom: 'C', lonePairs: 0, bonds: [['C','H',1],['C','H',1],['C','H',1],['C','H',1]], isIonic: false },
        'NaCl': { atoms: ['Na','Cl'], centralAtom: 'Na', lonePairs: 0, bonds: [['Na','Cl',1]], isIonic: true },
        'C2H5OH': { atoms: ['C','C','H','H','H','H','H','O','H'], centralAtom: 'C', lonePairs: 0, bonds: [['C','C',1],['C','H',1],['C','H',1],['C','H',1],['C','O',1],['C','H',1],['C','H',1],['O','H',1]], isIonic: false },
        'C6H6': { atoms: ['C','C','C','C','C','C','H','H','H','H','H','H'], centralAtom: 'C', lonePairs: 0, bonds: [['C','C',1.5],['C','C',1.5],['C','C',1.5],['C','C',1.5],['C','C',1.5],['C','C',1.5],['C','H',1],['C','H',1],['C','H',1],['C','H',1],['C','H',1],['C','H',1]], isIonic: false, hasAromatic: true },
        'NaOH': { atoms: ['Na','O','H'], centralAtom: 'O', lonePairs: 1, bonds: [['Na','O',1],['O','H',1]], isIonic: true },
        'HBr': { atoms: ['H','Br'], centralAtom: 'H', lonePairs: 0, bonds: [['H','Br',1]], isIonic: false },
        'HI': { atoms: ['H','I'], centralAtom: 'I', lonePairs: 0, bonds: [['H','I',1]], isIonic: false },
        'O2': { atoms: ['O','O'], centralAtom: 'O', lonePairs: 1, bonds: [['O','O',2]], isIonic: false },
        'N2': { atoms: ['N','N'], centralAtom: 'N', lonePairs: 1, bonds: [['N','N',3]], isIonic: false },
    };

    const cfg = configs[formula];
    if (!cfg) return null;

    const atoms = cfg.atoms.map(s => ELEM[s]);
    const MW = atoms.reduce((s, e) => s + e.mass, 0);
    const nAtoms = atoms.length;
    const allSame = atoms.every(a => a === atoms[0]);

    // H-bond analysis
    let hBondDonors = 0, hBondAcceptors = 0;
    const hbAtoms = ['N','O','F'];
    cfg.bonds.forEach(([a,b]) => {
        if (a === 'H' && hbAtoms.includes(b)) hBondDonors++;
        if (b === 'H' && hbAtoms.includes(a)) hBondDonors++;
    });
    // Simplified acceptor count
    cfg.atoms.forEach(s => {
        if (hbAtoms.includes(s)) {
            const valence = s === 'N' ? 5 : s === 'O' ? 6 : 7;
            const bondOrders = cfg.bonds.filter(([a,b]) => a === s || b === s).reduce((sum,[,,o]) => sum + (o||1), 0);
            const lp = Math.max(0, Math.floor((valence - bondOrders) / 2));
            hBondAcceptors += lp;
        }
    });
    const effectiveHBonds = Math.min(hBondDonors, hBondAcceptors);

    // EN analysis
    let totalENDiff = 0, maxENDiff = 0;
    cfg.bonds.forEach(([a,b]) => {
        const d = Math.abs((ELEM[a]?.en||2) - (ELEM[b]?.en||2));
        totalENDiff += d;
        if (d > maxENDiff) maxENDiff = d;
    });
    const avgENDiff = totalENDiff / cfg.bonds.length;

    // H-bond EN
    let avgHBondEN = 0;
    if (hBondDonors > 0) {
        let t = 0, c = 0;
        cfg.bonds.forEach(([a,b]) => {
            if (a === 'H' && hbAtoms.includes(b)) { t += ELEM[b].en; c++; }
            if (b === 'H' && hbAtoms.includes(a)) { t += ELEM[a].en; c++; }
        });
        avgHBondEN = c > 0 ? t / c : 0;
    }

    const nHeavyAtoms = cfg.atoms.filter(s => s !== 'H').length || 1;

    // Central atom analysis
    const centralSym = cfg.centralAtom;
    const centralBonds = cfg.bonds.filter(([a,b]) => a === centralSym || b === centralSym);
    const terminalSyms = centralBonds.map(([a,b]) => a === centralSym ? b : a);
    const isSymmetric = terminalSyms.every(s => s === terminalSyms[0]);
    const centralLP = cfg.lonePairs;
    const isLinearShape = terminalSyms.length === 2 && centralLP === 0;

    // Rotatable bonds
    let nRotatable = 0;
    cfg.bonds.forEach(([a,b,o]) => {
        if (o !== 1 || a === 'H' || b === 'H') return;
        const aBonds = cfg.bonds.filter(([x,y]) => x === a || y === a).length;
        const bBonds = cfg.bonds.filter(([x,y]) => x === b || y === b).length;
        if (aBonds >= 2 && bBonds >= 2) nRotatable++;
    });

    // z-product for ionic
    let zProduct = 1;  // simplified: always 1 for NaCl/NaOH

    const props = {
        MW, nAtoms, isIonic: cfg.isIonic, isMetallic: false,
        effectiveHBonds, hBondDonors, hBondAcceptors,
        avgENDiff, maxENDiff, avgHBondEN, nHeavyAtoms,
        isSymmetric, isLinearShape, nTerminalGroups: terminalSyms.length,
        centralAtomLonePairs: centralLP, nRotatable,
        zProduct, allSameElement: allSame,
        isDiatomicNonmetal: isDiatomicNonmetal,
        hasAromaticRing: cfg.hasAromatic || false,
    };

    // --- BP estimation (new algorithm) ---
    let bp;

    if (props.isIonic) {
        bp = 602 + 322 * maxENDiff * zProduct + 6.25 * MW;
    } else if (nAtoms === 1) {
        bp = atoms[0].boil || 2.0 * Math.pow(MW, 0.9);
    } else if (nAtoms === 2 && allSame) {
        bp = atoms[0].boil;
    } else if (nAtoms === 2 && !allSame) {
        const el1 = atoms[0], el2 = atoms[1];
        if (isDiatomicNonmetal(el1) && isDiatomicNonmetal(el2)) {
            const baseTb = (el1.boil + el2.boil) / 2;
            const deltaEN = Math.abs(el1.en - el2.en);
            const mu = deltaEN > 0.01 ? 1.121 * Math.pow(deltaEN, 0.924) : 0;
            const muSq = mu * mu;
            let dipCorr = 0;
            if (effectiveHBonds === 0 && muSq > 0.303) {
                dipCorr = 67.6 * (muSq - 0.303);
            }
            const hbCorr = effectiveHBonds > 0
                ? 20.919867 * Math.pow(effectiveHBonds, 0.8628) * avgHBondEN * (1 + 1.0316 / nHeavyAtoms)
                : 0;
            bp = baseTb + dipCorr + hbCorr;
        } else {
            // Fallback
            let Tb_london = 11.39695 * Math.pow(MW, 2/3) * (1 + 0.3364 * Math.log(nAtoms));
            bp = Tb_london;
        }
    } else {
        let Tb_london = 11.39695 * Math.pow(MW, 2/3) * (1 + 0.3364 * Math.log(nAtoms));
        if (props.hasAromaticRing) Tb_london *= 0.924;

        const symCancel = isSymmetric && centralLP === 0 && (isLinearShape || terminalSyms.length >= 3);
        const Tb_dipole = (!symCancel && avgENDiff > 0.4 && effectiveHBonds === 0) ? 20 * avgENDiff : 0;
        const Tb_hbond = effectiveHBonds > 0
            ? 20.919867 * Math.pow(effectiveHBonds, 0.8628) * avgHBondEN * (1 + 1.0316 / nHeavyAtoms) : 0;
        bp = Tb_london + Tb_dipole + Tb_hbond;
    }

    // --- MP estimation (new algorithm) ---
    let mp;
    if (props.isIonic) {
        if (effectiveHBonds > 0) {
            mp = bp * 0.36;
        } else {
            const ratio = Math.min(0.46 + 0.003 * MW, 0.75);
            mp = bp * ratio;
        }
    } else if (nAtoms === 1) {
        mp = atoms[0].melt || bp * 0.75;
    } else if (nAtoms === 2 && allSame) {
        mp = atoms[0].melt;
    } else if (nAtoms === 2 && !allSame) {
        const ratio = Math.min(0.8 + 0.001 * MW, 0.95);
        mp = bp * ratio;
    } else if (nAtoms <= 2) {
        mp = bp * 0.75;
    } else if (nRotatable === 0) {
        let Tm = 20.003 * Math.pow(MW, 0.5);
        if (isSymmetric && nAtoms <= 5) {
            if (isLinearShape && nAtoms >= 3) Tm *= 1.6;
            else if (terminalSyms.length >= 4) Tm *= 1.1319;
        }
        if (effectiveHBonds > 0) {
            Tm *= (1 + 0.979211 * effectiveHBonds + 0.1294 * hBondDonors);
        }
        mp = Tm;
    } else {
        let ratio = effectiveHBonds > 0 ? 0.7305 : 0.75;
        ratio *= Math.exp(-0.2394 * nRotatable);
        mp = bp * ratio;
    }

    return { bp, mp, MW };
}

console.log('Formula  |  BP calc  |  BP exp  |  BP diff  |  MP calc  |  MP exp  |  MP diff  |  MW calc  |  MW exp');
console.log('-'.repeat(110));

TEST_MOLECULES.forEach(t => {
    const r = simulateEngine(t.formula);
    if (!r) { console.log(t.formula + ': SKIP'); return; }

    const bpDiff = Math.abs(r.bp - t.expBP);
    const mpDiff = Math.abs(r.mp - t.expMP);
    const mwDiff = Math.abs(r.MW - t.expMW);

    const bpOk = bpDiff <= 5;
    const mpOk = mpDiff <= 5;
    const mwOk = mwDiff < 0.01;

    if (bpOk) bpPass++; else bpFail++;
    if (mpOk) mpPass++; else mpFail++;

    console.log(
        `${t.formula.padEnd(8)} | ${r.bp.toFixed(1).padStart(8)}K | ${String(t.expBP).padStart(7)}K | ${bpDiff.toFixed(1).padStart(6)}K ${bpOk?'✅':'❌'} | ` +
        `${r.mp.toFixed(1).padStart(8)}K | ${String(t.expMP).padStart(7)}K | ${mpDiff.toFixed(1).padStart(6)}K ${mpOk?'✅':'❌'} | ` +
        `${r.MW.toFixed(3).padStart(8)} | ${t.expMW.toFixed(3).padStart(8)} ${mwOk?'✅':'❌'}`
    );
});

console.log('\n=== SUMMARY ===');
console.log(`Boiling points: ${bpPass}/${bpPass+bpFail} within ±5K`);
console.log(`Melting points: ${mpPass}/${mpPass+mpFail} within ±5K`);
