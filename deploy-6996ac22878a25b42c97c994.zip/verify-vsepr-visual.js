// Verify VSEPR Visual Renderer — tests all required geometries
// Run: node verify-vsepr-visual.js

const fs = require('fs');
const path = require('path');

// Load the visual renderer source to test layout definitions
const src = fs.readFileSync(path.join(__dirname, 'public/js/vsepr-visual.js'), 'utf8');

// Simple eval to get the class (browser-like env)
const mockWindow = {};
global.window = mockWindow;
global.document = { querySelectorAll: () => [], getElementById: () => null };
eval(src);

const vis = mockWindow.vsepVisual;
if (!vis) { console.error('FAIL: VSEPRVisual not instantiated'); process.exit(1); }

const tests = [
    { key: '2-0', name: 'Linear (CO2)', bonds: 2, lones: 0 },
    { key: '3-0', name: 'Trigonal Planar (BF3)', bonds: 3, lones: 0 },
    { key: '2-1', name: 'Bent from TP (SO2)', bonds: 2, lones: 1 },
    { key: '4-0', name: 'Tetrahedral (CH4)', bonds: 4, lones: 0 },
    { key: '3-1', name: 'Trigonal Pyramidal (NH3)', bonds: 3, lones: 1 },
    { key: '2-2', name: 'Bent from Tet (H2O)', bonds: 2, lones: 2 },
    { key: '5-0', name: 'Trigonal Bipyramidal (PCl5)', bonds: 5, lones: 0 },
    { key: '4-1', name: 'Seesaw (SF4)', bonds: 4, lones: 1 },
    { key: '3-2', name: 'T-shaped (ClF3)', bonds: 3, lones: 2 },
    { key: '2-3', name: 'Linear from TBP (XeF2)', bonds: 2, lones: 3 },
    { key: '6-0', name: 'Octahedral (SF6)', bonds: 6, lones: 0 },
    { key: '5-1', name: 'Square Pyramidal (BrF5)', bonds: 5, lones: 1 },
    { key: '4-2', name: 'Square Planar (XeF4)', bonds: 4, lones: 2 },
];

let pass = 0, fail = 0;

tests.forEach(t => {
    const layout = vis.layouts[t.key];
    if (!layout) {
        console.error(`FAIL: Missing layout for ${t.key} (${t.name})`);
        fail++;
        return;
    }
    if (layout.bonds !== t.bonds) {
        console.error(`FAIL: ${t.name} bonds=${layout.bonds}, expected ${t.bonds}`);
        fail++;
        return;
    }
    if (layout.lones !== t.lones) {
        console.error(`FAIL: ${t.name} lones=${layout.lones}, expected ${t.lones}`);
        fail++;
        return;
    }
    if (layout.domains.length !== t.bonds + t.lones) {
        console.error(`FAIL: ${t.name} domains=${layout.domains.length}, expected ${t.bonds + t.lones}`);
        fail++;
        return;
    }
    // Verify all domains have x,y
    for (let i = 0; i < layout.domains.length; i++) {
        const d = layout.domains[i];
        if (typeof d.x !== 'number' || typeof d.y !== 'number') {
            console.error(`FAIL: ${t.name} domain[${i}] missing x/y`);
            fail++;
            return;
        }
    }
    console.log(`PASS: ${t.name} (${t.key}) — ${layout.domains.length} domains`);
    pass++;
});

// Test render function produces SVG
const mockVseprData = {
    centralAtom: 'O', centralAtomName: 'Oxygen',
    bondingPairs: 2, lonePairs: 2, totalPairs: 4,
    electronGeometry: 'Tetrahedral', molecularGeometry: 'Bent',
    bondAngle: 104.5, polarity: 'Polar',
    polarityExplanation: 'Bent geometry with 2 lone pairs',
    dipoleStrength: 1.85, bondData: []
};

const mockMolecule = { atomIds: ['a1', 'a2', 'a3'] };
const atomO = { id: 'a1', element: { symbol: 'O', name: 'Oxygen', cpk_hex: 'FF0D0D' } };
const atomH1 = { id: 'a2', element: { symbol: 'H', name: 'Hydrogen', cpk_hex: 'FFFFFF' } };
const atomH2 = { id: 'a3', element: { symbol: 'H', name: 'Hydrogen', cpk_hex: 'FFFFFF' } };
const mockEngine = {
    atoms: [atomO, atomH1, atomH2],
    bonds: [
        { a1: atomO, a2: atomH1 },
        { a1: atomO, a2: atomH2 },
    ]
};

const html = vis.render(mockVseprData, mockMolecule, mockEngine);
if (html.includes('<svg') && html.includes('</svg>')) {
    console.log('PASS: render() produces SVG for H2O');
    pass++;
} else {
    console.error('FAIL: render() did not produce SVG');
    fail++;
}

if (html.includes('vsepr-lp')) {
    console.log('PASS: render() includes lone pair elements');
    pass++;
} else {
    console.error('FAIL: render() missing lone pair elements');
    fail++;
}

if (html.includes('104.5')) {
    console.log('PASS: render() includes bond angle 104.5');
    pass++;
} else {
    console.error('FAIL: render() missing bond angle');
    fail++;
}

if (html.includes('playVSEPRAnimation')) {
    console.log('PASS: render() includes animation button');
    pass++;
} else {
    console.error('FAIL: render() missing animation button');
    fail++;
}

if (html.includes('Show Shape Transition')) {
    console.log('PASS: render() includes animation label');
    pass++;
} else {
    console.error('FAIL: render() missing animation label');
    fail++;
}

console.log(`\n${pass} passed, ${fail} failed out of ${pass + fail} tests`);
process.exit(fail > 0 ? 1 : 0);
